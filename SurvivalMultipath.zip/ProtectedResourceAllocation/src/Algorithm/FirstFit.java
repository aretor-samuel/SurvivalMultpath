package Algorithm;




import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

//import javafx.util.Pair;
import org.jgrapht.alg.util.Pair;

import TrafficGeneration.ServiceAssignment;
import TrafficGeneration.Service;
import Network.NodeId;
import Network.Link;
import Network.Link2;
import Network.LinkID;
import Network.LinkCores;
import Network.Node2;
import DataCollection. DataCollectionPerSC;
import Network.CoreSC;
import Network.FrequencySlots;
import Network.NodeIdImplement;
import Network.Nodeimplement;
import Network.TopologySetup;
import TrafficGeneration.Timestamp;
import Utility.Debug;


import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.KShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.shortestpath.KShortestPaths;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created on 2019/05/20.
 *Multi-core First Fit allocation algorithm 
 * @author sambabel.
 */
//public class CrosstalkAlgo extends BaseAlgorithm<Node2,Link2> extends FirstFit{
	public class FirstFit  extends BaseAlgorithm<Node2,Link2>{

//	public class FirstFitAllocAlgorithmn  {

    private static final Logger log = LoggerFactory.getLogger(FirstFit.class);
   // private DijkstraShortestPath<Nodeimplement, LinkImplementation> dijkstraShortestPath;
    private double threshold;
    //protected static GraphImplement graph;
    private SimpleWeightedGraph<Node2, Link2> graph;
    public static double mape;

    public static int predictionIntervalInMins =30;
    static final int minToMs = 60*1000;
    private Map<Link2, Double> futureMap;

    protected DataCollectionPerSC dataCollection;
    private DijkstraShortestPath<Node2, Link2> dijkstraShortestPath;
    private KShortestPathAlgorithm<Node2, Link2> kShortestPathAlgorithm;

    private int weightedCount=0;
    private int defaultCount=0;
    private int samePathCount=0;
    private int bothBlockCount=0;



    public static ArrayList<Integer>noCrosstalkSpectrumBlock=Lists.newArrayList();
    // ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

     public static List<CoreSC> coreSCList=Lists.newArrayList();
     
 
    public FirstFit(//double threshold,
                final ArrayList<Service> service,
                final ArrayList<Timestamp> serviceTimestamp,
                final SimpleWeightedGraph<Node2, Link2> graph
            
    		) {
    	super(  service,serviceTimestamp, graph);

dijkstraShortestPath = new DijkstraShortestPath<>(graph);


}


    
    

   
    public void Execute() {
    	
    	
  
    Calendar predictionTimePoint = Calendar.getInstance();
        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
            Timestamp timestamp = getServicesOrderedQueue().get(index);
            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

           
            if (timestamp.isStartTime()) {
            	
            	
              	 
              	  Node2 src = new Node2(serviceToBeAssigned.getSource());
                  Node2 dst = new Node2(serviceToBeAssigned.getDestination());
                  
             
                  GraphPath<Node2, Link2> defaultPath = dijkstraShortestPath.getPath(src, dst);
                //  int defaultSubscript = FindPathNoCrosstalkResourcesFirstAvailable2(defaultPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());

                  Pair<Integer,  List<Link2>> AvailablePath = FindPathNoCrosstalkResourcesFirstAvailable(defaultPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());
             //     int defaultSubscript = FindPathNoCrosstalkResourcesFirstAvailable5(defaultPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());

                 if (AvailablePath.getFirst() != BaseAlgorithm.UNAVAILABLE) {


   	              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
   	                    	
   	         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

   	            assignMulticasSpetrumResource1(serviceToBeAssigned, AvailablePath.getFirst(), noCrosstalkSpectrumBlock, coreSCList,  AvailablePath.getSecond());
   	      //	   System.out.println("**********************************Allocate pasedservices********************1111111111");




                 }  else {
                 	
                     handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());
                   System.out.println("******************************handblocked*******************************111111111112");

                 	
                 }
            } else {
            	// If it is a business departure event
               // return releaseService(serviceToBeAssigned);
                handleServiceLeave(serviceToBeAssigned.getEventId());
               System.out.println("**********************************handle pasedservices*************************88888*2");

            }
        }  
    }
   
	
    public boolean handleServiceLeave(int leaveServiceIndex) {
        if (getCurrentServices().containsKey(leaveServiceIndex)) {
            ServiceAssignment<Link2> serviceAssignment = getCurrentServices().get(leaveServiceIndex);
         //  releaseService(serviceAssignment.getService());
          releaseService1(serviceAssignment);
        //   releaseService12(serviceAssignment);

            putPassedService(
                    removeCurrentService(leaveServiceIndex));
        //   System.out.println(getPassedServices().size());
        } else if (getBlockedServices().containsKey(leaveServiceIndex)){
            // TODO
            // Actually, there is nothing to do here. Just for readability.
        } else {
            throw new RuntimeException("The leave service belongs to neither assigned services, nor blocked services.");
        }
		return true;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////
    private void releaseService1(ServiceAssignment<Link2> serviceAssignment) {
    	
  	  List<Link2> path = serviceAssignment.getPath();
  	  	//FrequencySlots slots
  	        int serviceIndex = serviceAssignment.getService().getEventId();
  	      //  for (int i = 0; i < 6 ; i++ ) {
  	           // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
  	            for (Link2 edge : path) {
  	            //    LinkImplementation sdmEdge = (LinkImplementation) edge;
  	                for (int slotIndex=serviceAssignment.getStartIndex();
  	                        slotIndex<=serviceAssignment.getStartIndex()+serviceAssignment.getService().getRequiredWaveNum()-2;
  	                      slotIndex++) {
  	                
  	                

  	    	 List<CoreSC> coreSCList = serviceAssignment.getCores();
  	         List<Integer> occupiedIndexes = serviceAssignment.getConnections();
  	         
	           List<LinkCores> sdmCorelist = edge.getCoreList();
;
	      	     for (LinkCores sdmCore : sdmCorelist) {


  	    //        if (sdmCore != null){
  	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();
  	              
      	                    if (wavelengths.get(slotIndex).getSlotIndex()==slotIndex && !wavelengths.get(slotIndex).getIsOccupied()) {//||
  	                          //  wavelengths.get(slotIndex).getWaveServiceId() != serviceIndex) {
  	                  
  	                    
  	                    	// If the service is successfully assigned when the service happens
  	                        throw new RuntimeException("Since the service does not occupy the corresponding resources, the service is released.\n" + 
  	                        		"！");
  	                   }
  	                
  	                    wavelengths.get(slotIndex).setOccupiedServiceIndex(0);;

  	                    
  	      
  	            }
  	  }
  	            }
    }
    public void handleAllocationFail(Service blockedService, int index) {
    	  
        addBlockedService(blockedService);
        //  System.out.println(getBlockedServices().size());
    

  //  	}
    }

    }



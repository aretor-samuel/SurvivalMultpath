package Algorithm;


import org.jgrapht.alg.util.Pair;

import Utility.Debug;
import Utility.RollbackException;
import Network.Link;
import Network.Link2;
import Network.LinkID;

import Network.LinkCores;
import Network.Node2;
import Network.NodeIdImplement;
import TrafficGeneration.Service;
import Network.CoreSC;
import Network.FrequencySlots;
import TrafficGeneration.Timestamp;
import TrafficGeneration.ServiceAssignment;
import org.jgrapht.GraphPath;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * Created on 2017/05/19.
 * 
 * @author sambabel.
 */
//public class BaseAlgorithm extends ControlAlgorithm {


//public class BaseAlgorithm<V, E extends Link2> extends ControlAlgorithm {
	public abstract class BaseAlgorithm<V, E extends Link2> {
	    private static final Logger log = LoggerFactory.getLogger(BaseAlgorithm.class);

	//private Graph graph;
	private SimpleWeightedGraph<V, E> graph;


    // services queue with service index ascend
    private ArrayList<Service> servicesQueue;

    // services queue with service startTime/endTime ascend, so each service will appear twice.
    private ArrayList<Timestamp> servicesOrderedQueue;
    // current services in Graph ordered by ascend. The key represents service index. Be called when new Service arrivals, and old service leaves.
    private  TreeMap<Integer, ServiceAssignment<E>> currentServices;
    // blocked services in Graph ordered by ascend. The key represents service index. Be called when new arrived service failures.
    private TreeMap<Integer, Service> blockedServices;
   // private TreeMap<Integer, FrequencySlots> spectrumSuccessShiftNum;
    public static ArrayList<Pair<Calendar, Integer>> serviceShiftTimeRecords = Lists.newArrayList();
    private List<Link2>path1=Lists.newArrayList();

    public static int serviceShiftTime = 0;
    // passed services in Graph ordered by ascend. The key represents service index. Be called when withdrawing current service.
    private TreeMap<Integer, ServiceAssignment<E>> passedServices;
    private  Set<Link2> linkSet= Sets.newHashSet();
    private static int occupiedNum; // the number of slots occupied by different services


    public static final int UNAVAILABLE = -1;

    /**
     * allocate spectrum resources to services' demand.
     */
   public abstract void Execute();

    public SimpleWeightedGraph<V, E> getGraph() {
        return graph;
    }

    public void setGraph(final SimpleWeightedGraph<V, E> graph) {
        this.graph = graph;
    }

    public ArrayList<Service> getServicesQueue() {
        return servicesQueue;
    }

    public void setServicesQueue(final ArrayList<Service> servicesQueue) {
        this.servicesQueue = servicesQueue;
    }

	public TreeMap<Integer, ServiceAssignment<E>> getCurrentServices() {
        return currentServices;
    }

    public TreeMap<Integer, Service> getBlockedServices() {
        return blockedServices;
    }
    
    

    public ArrayList<Timestamp> getServicesOrderedQueue() {
        return servicesOrderedQueue;
    }

    public TreeMap<Integer, ServiceAssignment<E>> getPassedServices() {
        return passedServices;
    }

    public void setServicesOrderedQueue(final ArrayList<Timestamp> servicesOrderedQueue) {
        this.servicesOrderedQueue = servicesOrderedQueue;
    }
    
    public  void putCurrentService(ServiceAssignment<E> serviceAssignment) {
        if (currentServices.containsKey(serviceAssignment.getService().getEventId())) {
            throw new RuntimeException("allocate the same services twice.");
        } else {
            currentServices.put(serviceAssignment.getService().getEventId(), serviceAssignment);
        }
    }

    /**
     * remove a service from current service map.
     * @param serviceIndex
     * @return
     */
    public ServiceAssignment<E> removeCurrentService(int serviceIndex) {
        return currentServices.remove(serviceIndex);
    }

    /**
     * put a passed service.
     * @param serviceAssignment
     */
    public void putPassedService(ServiceAssignment<E> serviceAssignment) {
        if (passedServices.containsKey(serviceAssignment.getService().getEventId())) {
            throw new RuntimeException("put duplicate passed service to passedServices");
        } else {
            passedServices.put(serviceAssignment.getService().getEventId(), serviceAssignment);
        }
    }
    public void addBlockedService(Service service) {
    	 if (passedServices.containsKey(service.getEventId())) {
             throw new RuntimeException("put duplicate bloacked service to bloakservice");
         } else {
        blockedServices.put(service.getEventId(), service);
         }
    }

/*
    public void addServiceShiftTime(int time, Calendar happenedTime) {
        serviceShiftTime = serviceShiftTime + time;
        serviceShiftTimeRecords.add(new Pair<>(happenedTime, time));
    }
    public static ArrayList<Pair<Calendar, Integer>> getServiceShiftTimeRecords() {
        return serviceShiftTimeRecords;
    }

    public static int getServiceShiftTime() {
        return serviceShiftTime;
    }*/
    
public BaseAlgorithm( final	ArrayList<Service> servicesQueue, final ArrayList<Timestamp> servicesOrderedQueue, final SimpleWeightedGraph<V, E> graph) { 
this.graph = graph;
this.servicesQueue = servicesQueue;
this.servicesOrderedQueue = servicesOrderedQueue;
this.currentServices = Maps.newTreeMap();
this.blockedServices = Maps.newTreeMap();
this.passedServices = Maps.newTreeMap();


}

	





protected  void assignMulticasSpetrumResource1(Service serviceEvent, int startIndex,List<Integer> finalResult, List<CoreSC> maxCoreScPerEdge, List<E> path) {

	
	
	  int eventId = serviceEvent.getEventId();
// reorder hops from least to greatest
//Collections.sort(nextHops);
//for(int j=0; j<weightedPaths.size(); j++) {
//	List<Link2> path=weightedPaths.get(j).getEdgeList();

///	for(int i = 0; i < listLen; i++) {
//	System.out.println("FMP " + timeNow + " " + destination + " " + nextHops.get(i));
	for (Link2 edge: path) {
		 
		List<LinkCores>sdmCores=edge.getCoreList();
	
		for (int i=startIndex; i<=startIndex+serviceEvent.getRequiredWaveNum()-3; i++) {

	  for ( LinkCores linkcores : sdmCores) {

        List<FrequencySlots> wavelengths =linkcores.getWavelength();

            if (wavelengths.get(i+1).getIsOccupied()) {
     
            log.error("Insufficient resources to allocate business");
        } 
        //    wavelengths.get(i).setOccupiedServiceIndex(eventId);
            wavelengths.get(i+1).setOccupiedServiceIndex(1);

         //   wavelengths.get(i.stwaveServiceId(eventId);
            wavelengths.get(i+1).accumulate();
           // accumulate();-

       // }
}

                                               
}


}
//    putCurrentService(new ServiceAssignment<>(serviceEvent,startIndex,LinkCores1,finalResult, path));

putCurrentService(new ServiceAssignment<>(serviceEvent, startIndex,maxCoreScPerEdge,finalResult, path));

	                                                   
	   }



protected int FindPathNoCrosstalkResourcesFirstAvailable4(List<Link2> path, int requireWaveNum) {
//	public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {

	//  ArrayList<Integer>finalResult = new ArrayList<>(); 
      // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
       ArrayList<Integer> list=new ArrayList<>();
         int k=0;
    //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
         ArrayList<Integer> avaiIntersectionList;
         if (path.isEmpty()) {
             return UNAVAILABLE;
         } else if (path.size() == 1){

      
                  avaiIntersectionList = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

                   if (avaiIntersectionList.size() < requireWaveNum) {
                       return UNAVAILABLE;
                   }
               } else {
                   
                    TreeSet<Integer> avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);


                   for (int i=1; i<path.size(); i++) {
                     TreeSet<Integer> specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
            	
                       intersection(avaiIntersectionSet, specificEdgeAvailSet);
                       // if the size of intersection set is small than requiredSlotNum, return -1.
                       if (avaiIntersectionSet.size() < requireWaveNum) {
                           return UNAVAILABLE;
                       }
                   }
                   // transform set to list.
                   // In TreeSet, over the elements in this set in ascending order.
                   avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
               }
                   
                   
                   
                 //  k=searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
                   
                   
           //     k= searchLowestAvaiIndex(finalResult, requireWaveNum);
  //}

 // }
   //    }
             //    }
		return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
  
  }
protected Pair<Integer,  List<Link2>> FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {
     ArrayList<Integer> avaiIntersectionList;
     if (path.isEmpty()) {

	  return new Pair<>(UNAVAILABLE, path);

     } else if (path.size() == 1){

  
     avaiIntersectionList = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

      if (avaiIntersectionList.size() < requireWaveNum) {
	
      return new Pair<>(UNAVAILABLE, path);


        }
     } else {
               
                TreeSet<Integer> avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);


               for (int i=1; i<path.size(); i++) {
                 TreeSet<Integer> specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
        	
                   intersection(avaiIntersectionSet, specificEdgeAvailSet);
                   // if the size of intersection set is small than requiredSlotNum, return -1.
                   if (avaiIntersectionSet.size() < requireWaveNum) {
        		    
                	   return new Pair<>(UNAVAILABLE, path);

                   }
               }
               // transform set to list.
               // In TreeSet, over the elements in this set in ascending order.
               avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
           }
               
               
               
        
	return searchLowestAvaiIndex1(avaiIntersectionList, path, requireWaveNum);

}


  
  private static  Pair<Integer,  List<Link2>> searchLowestAvaiIndex1(ArrayList<Integer> list, List<Link2> path, int requiredNum) {
	//  Map<Integer,  List<Link2>> AvailablePath=new HashMap<Integer,  List<Link2>>();;      

		
      if (requiredNum == 1) {
    	//  AvailablePath.put(list.get(0), path);
          //return list.get(0);
       //   return AvailablePath;
	       return new Pair<>(list.get(0), path);


      }
      int startIndex = list.get(0);
      int continuousNum = 1;
      for (int i=1; i<list.size(); i++) {
          if (list.get(i) == startIndex+continuousNum) {
              continuousNum++;
          } else {
              startIndex = list.get(i);
              continuousNum = 1;
          }
          // if find the first spectrum block which is satisfied.
          if (continuousNum == requiredNum) {
        	//  AvailablePath.put(startIndex, path);
   	       return new Pair<>(startIndex, path);


        	  
           //   return startIndex;
       //       return AvailablePath;

          }
      }
	//  AvailablePath.put(UNAVAILABLE, path);
      return new Pair<>(UNAVAILABLE, path);


     // return AvailablePath;
  }
  private static int searchLowestAvaiIndex(ArrayList<Integer> list, int requiredNum) {
      if (requiredNum == 1) {
          return list.get(0);
      }
      int startIndex = list.get(0);
      int continuousNum = 1;
      for (int i=1; i<list.size(); i++) {
          if (list.get(i) == startIndex+continuousNum) {
              continuousNum++;
          } else {
              startIndex = list.get(i);
              continuousNum = 1;
          }
          // if find the first spectrum block which is satisfied.
          if (continuousNum == requiredNum) {
              return startIndex;
          }
      }

      return UNAVAILABLE;
  }

      private static ArrayList<Integer> treesetToArraylist(TreeSet<Integer> treeSet) {
          Iterator<Integer> iterator = treeSet.iterator();
          ArrayList<Integer> list = Lists.newArrayList();
          while (iterator.hasNext()) {
              list.add(iterator.next());
          }
          return list;
      }

      private static void intersection(TreeSet<Integer> original, TreeSet<Integer> compared) {
          ArrayList<Integer> duplicate = original.stream().filter(index -> !compared.contains(index)).collect(Collectors.toCollection(ArrayList::new));
          duplicate.forEach(original::remove);
      }
      private static void intersection1(ArrayList<Integer> original, ArrayList<Integer> compared) {
          ArrayList<Integer> duplicate = original.stream().filter(index -> !compared.contains(index)).collect(Collectors.toCollection(ArrayList::new));
          duplicate.forEach(original::remove);
      }
	}
      
    /**
	@Override
    protected boolean handle(LinkCores worstCore , List<Integer> occupiedByConn, int connectionId ,
                             Graph originGraph, int eventIndex, long startTime, List<Timestamp> orderedList){

    	//First you need to define two constraints:
            // 1. The spectrum allocation for the service must be continuous, that is, if a service requires 2 spectrum resources, only consecutive numbers such as 1, 2, and 3 can be allocated.
            // 2. For the spectrum movement of a spectrum resource occupied by a service within a Core, the wavelength consistency of the entire path of the service must be guaranteed. ?
        int occupiedByConnNum = occupiedByConn.size();
        double oldWorstSc = calculateCoreSC(worstCore);

        try {
        	// Get all edges on the Path, and the specific SdmCore list on each side
         //   List<CoreSC> pathCoreSC= eventInfo.get(connectionId).getKey();
            List<CoreSC> pathCoreSC= eventInfo.get(connectionId).getFirst();
            List<Double> oldScValueList = new ArrayList<Double>();
            for (CoreSC coreSC : pathCoreSC){
                if (coreSC.getCoreIndex() != 6) {
                    LinkImplementation edge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
                    LinkCores sdmCore = edge.getCoreList().get(coreSC.getCoreIndex());
                    oldScValueList.add(calculateCoreSC(sdmCore));
                }
            }
            ////////////////////////////
           
            ////////////////////////////
            
            
            // Get a List of spectrum blocks on the worstCore that provide enough transfer resources, where the spectrum block is specified with List<SdmCore>
            // The available spectrum block adjacent to occupiedByConn gives occupiedByConn the possibility of smooth movement, which should be considered
            List<List<Integer>> avaiBlocksForSpecificConn = getWorstCoreAvaiBlock(worstCore,occupiedByConnNum);
                  // If there are available resources that can be moved

            if (avaiBlocksForSpecificConn.size() >= 1) {
            	// traverse available resources
            	for (int j=0; j<avaiBlocksForSpecificConn.size(); j++) {
                    List<Integer> specificBlock = avaiBlocksForSpecificConn.get(j);
                 
                 // First transfer the resource from the occupiedByConn to the specificBlock of the same Core, in addition to determining the specified spectrum segment on the current core.
                    // Also look at the entire Path of the spectrum segment is available, the consistency is available to move, and the following process
                    if (moveConnInCore(occupiedByConn, specificBlock, pathCoreSC, originGraph)) {
                       
                    	// If the move is successful, pathCoreSC will recalculate when comparing, but it will not be moved for the time being.
                        // If the core result on the entire Path after the transfer is greater than the threshold, then the transfer is valid.
                        if (allPathCoreScOverThres(pathCoreSC, oldScValueList, originGraph)) {
                        	// Will the test cause crosstalk, plus whether there is crosstalk in the core for the consistent spectrum segment on the entire Path?

                            if (!checkIfPathCrosstalk(specificBlock, pathCoreSC, originGraph)) {
                              
                            	// If there is no crosstalk, it means the adjustment is successful.
                                // There is a problem here. If the adjustment is successful, the break should jump out of the traversal of connections instead of just jumping out.
                                // Traversal of other available cores?
                                // Compliant with refactoring, the serviceId in the band of the sink core is also moved (previous wavelength occupation has been modified), and eventinfo is modified.

                                moveScConnectionId(occupiedByConn, specificBlock, connectionId, pathCoreSC, originGraph);
                                Calendar endTime = orderedList.get(0).getTime();
                                addServiceShiftTime(connectionId,endTime);
                             //   dataCollection.addSpectrumSuccessShiftNum();
                          //      dataCollection.addReconstructTime(eventIndex, startTime, endTime);
                                log.info("The CasdDsSc algorithm was successfully reconstructed! The moving business is{}。", connectionId);
                                return true;
                            } else {
                               
                            	// If crosstalk occurs, this adjustment fails
                                // perform a rollback operation

                                if (!moveConnInCore(specificBlock, occupiedByConn, pathCoreSC,originGraph)) {
                                	// If the rollback fails, the program can be terminated.
                                    throw new RollbackException("回滚失败！");
                                }
                            }
                        } else {
                        	// If the new SC after modification cannot meet the threshold limit, it means that the adjustment fails, and the spectrum transfer situation needs to be rolled back.
                            if (!moveConnInCore(specificBlock, occupiedByConn, pathCoreSC, originGraph)) {
                            	// If the rollback fails, the program can be terminated.
                                throw new RollbackException("回滚失败！");
                            }
                        }
                    } else {
                    	// do nothing, then find the next spectrum block
                    }
                }
            } else {
                return false;
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        return false;
    }
	*/
		  
    /**
     *
     *   Get a List of spectrum blocks on the worstCore that provide sufficient transfer resources, where the spectrum block is specified with List<SdmCore> - the test is successful
      * @param occupiedByConnNum The wavelength resource occupied by the connection
      * @return other available spectrum segments on the core
     */
/*	protected List<List<Integer>> getWorstCoreAvaiBlock(LinkCores worstCore, int occupiedByConnNum){

        List<List<Integer>> availCoreBlock = new ArrayList<List<Integer>>();
        List<FrequencySlots> worstCoreWaveList = worstCore.getWavelength();
     // traverse the wavelength of 1-49, while traversing the length of 0-Num, the number follows the wavelength number. If consecutive Num wavelength numbers are available, add Block.
        //If it is not continuous, it will traverse the wavelength from the next wavelength number. Every time it is traversed, it will re-empt the count and the new new list.
        for (int i = 0;i < worstCoreWaveList.size()-occupiedByConnNum+1; i++){
            int count = 0;
            List<Integer> availSpectrumSlots = new ArrayList<Integer>();
            for (int j = i; j < i+occupiedByConnNum; j++){
                if (!worstCoreWaveList.get(j).getIsOccupied()){
                    count = count +1;
                    availSpectrumSlots.add(worstCoreWaveList.get(j).getId());
                }
                else {
                    break;
                }
            }
            if (count == occupiedByConnNum){
                availCoreBlock.add(availSpectrumSlots);
            }
        }
        return availCoreBlock;
    }*/

    /**
     * 
     * To move the specified spectrum segment on the Core to other available spectrum segments in the same core, you first need to determine the specified spectrum segment on the current core.
      * Also depends on whether the spectrum segment of the entire Path is available. If the consistency is available, move it and return true.
      * @param occupiedByConn specified spectrum segment to be moved
      * @param specificBlock ith available spectrum segment
      * @param coreScListPath The list of cores occupied by each edge of the entire Path
      * @return If the entire Path specified spectrum segment is available, move, move successfully, return true; unavailable, return false directly, traverse the next block
     */
  /**  private boolean moveConnInCore(List<Integer> occupiedByConn, List<Integer> specificBlock
            ,List<CoreSC> coreScListPath, Graph originGraph){

        int countAvailCoreNum = 0;
        for (CoreSC coreSC : coreScListPath){
            int countOccuNum = 0;
            LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
            List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
            for (int i = 0; i< specificBlock.size(); i++){
                if(!coreWavelength.get(specificBlock.get(i)).getIsOccupied()){
                    countOccuNum = countOccuNum + 1;
                }
            }
            if (countOccuNum == specificBlock.size()){
                countAvailCoreNum = countAvailCoreNum + 1;
            }
            else {
                return false;
            }
        }

        if (countAvailCoreNum == coreScListPath.size()){
            for (CoreSC coreSC : coreScListPath) {
             LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
                LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
                List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
                for (int i = 0; i < occupiedByConn.size(); i++) {
                    coreWavelength.get(occupiedByConn.get(i)).setOccupiedServiceIndex(1);
                }
                for (int j = 0; j < specificBlock.size(); j++) {
                    coreWavelength.get(specificBlock.get(j)).setOccupiedServiceIndex(0);
                }
                coreSC.setSc(calculateCoreSC(sdmCore));
            }
            return true;
        }else {
            return false;
        }
    }*/

    /**
     * checking if the spectrum compactness of the cores in the path exceed threshold
      * @return exceeds the threshold, exceeds the return true, no more than the need to traverse the next block

     */
/*   public boolean allPathCoreScOverThres(List<CoreSC> pathCoreSC, List<Double> scValueList, Graph originGraph){
      //  public boolean allPathCoreScOverThres(List<CoreSC> pathCoreSC, double scValueList, Graph originGraph){

    	//The SC value of all cores on the entire Path is adjusted to be higher than the previous SC value, then it returns true.
        // Note that the pathCoreSC has been recalculated here, first move it, wait for it to move again.

        int conut = 0;
        for (int i = 0; i <  pathCoreSC.size(); i++){
        	LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(pathCoreSC.get(i).getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(pathCoreSC.get(i).getCoreIndex());
            double perSc = calculateCoreSC(sdmCore);
            if (perSc > scValueList.get(i)){
             //   if (perSc > scValueList){
                conut++;
            }
        }
        if (conut == pathCoreSC.size()){
            return true;
        }else {
            return false;
        }
    }*/

    /**
     * Checking whether there is  crosstalk in the new spectrum slot and on the consistent spectrum segment in the entire path
      * 
     */
    /*private boolean checkIfPathCrosstalk(List<Integer> specificBlock, List<CoreSC> coreScListPath,
                                         Graph originGraph){
    	// Record the number of edges that satisfy the crosstalk condition, and compare it with the total number of edges.

        int countNonCrosstalkCore = 0;

        for (CoreSC coreSC : coreScListPath){
        	// Side information, nuclear information, adjacent nuclear information

        	LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
            List<LinkCores> adjacentCoreList = sdmCore.getAdjacentCores();

         // Traversing the newly occupied spectrum segment of the sink core, whether its neighboring two cores are equally occupied, and no crosstalk
            int countSpecOccu = 0;
            for (int i = 0; i < specificBlock.size(); i++) {
                int index = specificBlock.get(i);
             // traverse all neighboring cores of the core
                int countAdjCoreOccu = 0;
                for (LinkCores adjacentCore : adjacentCoreList) {
                    if (adjacentCore.getWavelength().get(index).getIsOccupied()){
                        countAdjCoreOccu++;
                    }
                }
             // Remove itself, the total number of adjacent cores is only three, countAdjCoreOccu counts the number of adjacent cores
              //TODO modified the crosstalk condition
                if (countAdjCoreOccu >= adjacentCoreList.size()){
                	// greater than or equal to 3 indicates crosstalk
                    return true;
                }else {
                	// Explain that the indexSlot has no crosstalk, countSpecOccu plus one
                    countSpecOccu++;
                }
            }

            if (countSpecOccu == specificBlock.size()){
                countNonCrosstalkCore++;
            }
        }

            //The spectrum is the same no more than two hops. The core has no crosstalk. Then it is judged that the Path is next to the Core. All the Cores on the Path have no crosstalk.
        //All Cores on Path have no crosstalk, success, return false without crosstalk
        if (countNonCrosstalkCore == coreScListPath.size()){
            return false;
        }else {
            return true;
        }

    }
	}*/

    /**
     * 
     * Move the connectionId of the specified band on the entire Path to the path and modify the eventInfo.
      * @param occupiedByConn specified spectrum segment to be moved
      * @param specificBlock ith available spectrum segment
      * @param coreScListPath The list of cores occupied by each edge of the entire Path

     */
/*    private void moveScConnectionId(List<Integer> occupiedByConn, List<Integer> specificBlock, int connectionId,
                                    List<CoreSC> coreScListPath, Graph originGraph) {
        if (occupiedByConn.size() != specificBlock.size()) {
            throw new RuntimeException("when the same core moves, the source and sink spectrum segments are different in length!"); //  W
        }

        //搬移connectionId
        for (CoreSC coreSC : coreScListPath){
            LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
            List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
            for (int i = 0;i < occupiedByConn.size(); i++){
                coreWavelength.get(occupiedByConn.get(i)).setwaveServiceId(-1);
            }
            for (int j = 0; j < specificBlock.size(); j++){
                coreWavelength.get(specificBlock.get(j)).setwaveServiceId(connectionId);
            }
        }
     // Modify eventInfo, only modify List<Integer>, the spectrum segment corresponding to connectionId has changed.

       // List<Integer> spectrumSlotsList = eventInfo.get(connectionId).getValue();
        List<Integer> spectrumSlotsList = eventInfo.get(connectionId).getSecond();
        for (int k = 0; k < specificBlock.size(); k++){
            spectrumSlotsList.set(k, specificBlock.get(k));
        }
      //  List<CoreSC> coreSCList = eventInfo.get(connectionId).getKey();
        List<CoreSC> coreSCList = eventInfo.get(connectionId).getFirst();
        for (CoreSC coreSC : coreSCList){
        	LinkImplementation edge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = edge.getCoreList().get(coreSC.getCoreIndex());
            coreSC.setSc(calculateCoreSC(sdmCore));
        }
    }

}
*/
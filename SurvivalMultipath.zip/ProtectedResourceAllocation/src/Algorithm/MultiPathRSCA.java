package Algorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.KShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.shortestpath.KShortestPaths;
import org.jgrapht.alg.util.Pair;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.common.collect.Lists;

import Network.CoreSC;
import Network.FrequencySlots;
import Network.Link2;
import Network.LinkCores;
import Network.Node2;
import Network.NodeIdImplement;
import Network.TopologySetup;
import Algorithm.BaseAlgorithm;
import TrafficGeneration.Service;
import TrafficGeneration.ServiceAssignment;
import TrafficGeneration.Timestamp;

public class MultiPathRSCA extends FirstFit{
    private static final Logger log = LoggerFactory.getLogger(MultiPathRSCA.class);


	
    private SimpleWeightedGraph<Node2, Link2> graph;
    final int k;
    private Set<Integer>vertexes;
    public static ArrayList<Integer>noCrosstalkSpectrumBlock=Lists.newArrayList();
    // ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

     public static List<CoreSC> coreSCList=Lists.newArrayList();

	
	private DijkstraShortestPath<Node2, Link2> dijkstraShortestPath;
    private KShortestPathAlgorithm<Node2, Link2> kShortestPathAlgorithm;
    private int weightedCount=0;
    private int defaultCount=0;
    private int samePathCount=0;
    private int bothBlockCount=0;

public  MultiPathRSCA(int k,
		//Set<Integer>vertexes,
        //double alpha,
        final ArrayList<Service> service,
        final ArrayList<Timestamp> serviceTimestamp,
        final SimpleWeightedGraph<Node2, Link2> graph) {
	super(  service,serviceTimestamp, graph);
	dijkstraShortestPath = new DijkstraShortestPath<>(graph);
	kShortestPathAlgorithm = new KShortestPaths<>(graph, k);
this.k=k;
this.vertexes=vertexes;
	//public void Execute() {
}
	
	public void Execute() {
		

	    Calendar predictionTimePoint = Calendar.getInstance();
	        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

	        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
	            Timestamp timestamp = getServicesOrderedQueue().get(index);
	            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

	
	
	            if (timestamp.isStartTime()) {
	            		
     	  Node2 src = new Node2(serviceToBeAssigned.getSource());
         Node2 dst = new Node2(serviceToBeAssigned.getDestination());
         
         GraphPath<Node2, Link2> BackupPath = dijkstraShortestPath.getPath(src, dst);
         Pair<Integer,  List<Link2>> BackupPathResource= FindPathNoCrosstalkResourcesFirstAvailable( BackupPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());

         
         
         List<GraphPath<Node2, Link2>> weightedPaths = kShortestPathAlgorithm.getPaths(src, dst);

        
        weightedPaths.sort(new Comparator<GraphPath<Node2, Link2>>() {
            @Override
            public int compare(GraphPath<Node2, Link2> o1, GraphPath<Node2, Link2> o2) {
                if (o1.getLength() > o2.getLength()) {
                    return 1;
                } else if (o1.getLength() < o2.getLength()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });
        List<Pair<Integer,  List<Link2>>> CandidatePaths = Lists.newArrayListWithExpectedSize(weightedPaths.size());
        List<List<Link2>>CandidatePaths1 = Lists.newArrayListWithExpectedSize(weightedPaths.size());
		List<Integer> FirstAvailableSlot=Lists.newArrayListWithExpectedSize(weightedPaths.size());

        for (GraphPath<Node2, Link2> weightedPath : weightedPaths) {
      //  int weightedSubscript = FindPathNoCrosstalkResourcesFirstAvailable5(
                //   int weightedSubscript = FindPathNoCrosstalkResourcesFirstAvailable2(
              //         int weightedSubscript = FindPathNoCrosstalkResourcesFirstAvailable4(
        	 Pair<Integer,  List<Link2>> AvailablePath= FindPathNoCrosstalkResourcesFirstAvailable(



                    weightedPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());
        	 CandidatePaths.add(AvailablePath);
        //	 CandidatePaths1.add(  weightedPath.getEdgeList());
        //	 FirstAvailableSlot.add(weightedSubscript);
        }
        List<Pair<Integer, List<Link2>>> BetterMultiPath=compare1(BackupPathResource ,CandidatePaths);
      //List<Pair<Integer, List<Link2>>> BetterMultiPath=compare(BackupPathResource , CandidatePaths);
							
        //    if (BetterMultiPath.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE) {
            //    if (CandidatePaths.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE) {
                    if (CandidatePaths.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE) {




	              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
	                    	
	         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

	       //     assignMulticasSpetrumResource1(serviceToBeAssigned, BetterMultiPath.get(0).getFirst(), noCrosstalkSpectrumBlock, coreSCList,  BetterMultiPath.get(0).getSecond());
	      	 //  System.out.println("**********************************Allocate pasedservices********************1111111111");
	            assignMulticasSpetrumResource1(serviceToBeAssigned, CandidatePaths.get(0).getFirst(), noCrosstalkSpectrumBlock, coreSCList,  CandidatePaths.get(0).getSecond());


	                     } 
                    
                    else   if (CandidatePaths.get(1).getFirst() != BaseAlgorithm.UNAVAILABLE) {




      	              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
      	                    	
      	         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

      	       //     assignMulticasSpetrumResource1(serviceToBeAssigned, BetterMultiPath.get(0).getFirst(), noCrosstalkSpectrumBlock, coreSCList,  BetterMultiPath.get(0).getSecond());
      	      	 //  System.out.println("**********************************Allocate pasedservices********************1111111111");
      	            assignMulticasSpetrumResource1(serviceToBeAssigned, CandidatePaths.get(1).getFirst(), noCrosstalkSpectrumBlock, coreSCList,  CandidatePaths.get(1).getSecond());
                    }
            else  if (BackupPathResource.getFirst() != BaseAlgorithm.UNAVAILABLE) {


	              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
	                    	
	         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

	            assignMulticasSpetrumResource1(serviceToBeAssigned, BackupPathResource.getFirst(), noCrosstalkSpectrumBlock, coreSCList,  BackupPathResource.getSecond());
	      	 //  System.out.println("**********************************Allocate pasedservices********************1111111111");


	                     } 

	                     
	                     else {
	                 	
	                     handleAllocationFail(serviceToBeAssigned , index);
	      // 	  System.out.println("**********************************handleBlockedservices*************************4444444");

	                 }
   	//	 System.out.println(weightedPaths.get(0).getEdgeList().toString());

	            } else {
	            	// If it is a business departure event
	               // return releaseService(serviceToBeAssigned);
	                handleServiceLeave(serviceToBeAssigned.getEventId());
 // System.out.println("**********************************handle pasedservices*************************88888*2");
	                

	            }
	            
	        }  
	    }

	
	private List<Pair<Integer, List<Link2>>> compare1(Pair<Integer,  List<Link2>> BacKupPath ,List<Pair<Integer,  List<Link2>>> MultiPath) {
	     List<Pair<Integer,  List<Link2>>> CandidatePaths = Lists.newArrayListWithExpectedSize(MultiPath.size());

	 
	     if (MultiPath.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() != BaseAlgorithm.UNAVAILABLE) {
	    	    
	    	    
	  	   	     
	    	 CandidatePaths.add(new Pair<>(MultiPath.get(0).getFirst(), MultiPath.get(0).getSecond()));
	  			 return CandidatePaths;
	  }
	  else if (MultiPath.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()== BaseAlgorithm.UNAVAILABLE) {
	  	
		  CandidatePaths.add(new Pair<>(MultiPath.get(0).getFirst(), MultiPath.get(0).getSecond()));
	  	return	CandidatePaths;   
	  }//return directly)
	  else if (MultiPath.get(0).getFirst() == BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()!= BaseAlgorithm.UNAVAILABLE) {
		  	
		  CandidatePaths.add(new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond()));
	  	return	CandidatePaths;   
	  }//return directly)
	  else if (MultiPath.get(0).getFirst() == BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()== BaseAlgorithm.UNAVAILABLE) {
		  	
		  CandidatePaths.add(new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond()));
	  	return	CandidatePaths;   
	  }//return di
	  else {
		  CandidatePaths.add(new Pair<>(MultiPath.get(0).getFirst(), MultiPath.get(0).getSecond()));
		  	return	CandidatePaths;   

	  }
}
 private List<Pair<Integer, List<Link2>>> compare(Pair<Integer,  List<Link2>> BacKupPath ,List<Pair<Integer,  List<Link2>>> MultiPath) {
     List<Pair<Integer,  List<Link2>>> CandidatePaths = Lists.newArrayListWithExpectedSize(MultiPath.size());

 
for(int i=0; i<MultiPath.size(); i++) {
//Pair<GraphPath<Node2, Link2>, Integer> result =
Pair<Integer,  List<Link2>>RequiredResources=compare(BacKupPath, MultiPath.get(i));
// If the returned weightedPath, then jump out of the loop, return directly)
CandidatePaths.add(RequiredResources);
	
}
	return CandidatePaths;
 }	
 
 /**   * Compare the merits of the two paths calculated by the minimum hop count and the minimum weight.
  * @param defaultPath
  * @param defaultSubscript
  * @param weightedPath
  * @param weightedSubscript
  * @return
  */

private Pair<Integer,  List<Link2>> compare(Pair<Integer,  List<Link2>> BacKupPath, Pair<Integer,  List<Link2>> MultiPath) {

if (MultiPath.getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() != BaseAlgorithm.UNAVAILABLE) {
    
    
	   return	   new Pair<>(MultiPath.getFirst(), MultiPath.getSecond());
}
else if (MultiPath.getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()== BaseAlgorithm.UNAVAILABLE) {
	
	
	return	   new Pair<>(MultiPath.getFirst(), MultiPath.getSecond());
}
	
else if (MultiPath.getFirst() == BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() == BaseAlgorithm.UNAVAILABLE) {
	return	   new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond());

		
	}
else if (MultiPath.getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() != BaseAlgorithm.UNAVAILABLE) {
	return	   new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond());
}

else {
	return	new Pair<>(MultiPath.getFirst(), MultiPath.getSecond());
 
	}

}


 






	 
	
	
	/***
    public boolean handleServiceLeave(int leaveServiceIndex) {
        if (getCurrentServices().containsKey(leaveServiceIndex)) {
            ServiceAssignment<Link2> serviceAssignment = getCurrentServices().get(leaveServiceIndex);
         //  releaseService(serviceAssignment.getService());
          releaseService1(serviceAssignment);
        //   releaseService12(serviceAssignment);

            putPassedService(
                    removeCurrentService(leaveServiceIndex));
        //   System.out.println(getPassedServices().size());
        } else if (getBlockedServices().containsKey(leaveServiceIndex)){
            // TODO
            // Actually, there is nothing to do here. Just for readability.
        } else {
            throw new RuntimeException("The leave service belongs to neither assigned services, nor blocked services.");
        }
		return true;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////
    private void releaseService1(ServiceAssignment<Link2> serviceAssignment) {
    	
  	  List<Link2> path = serviceAssignment.getPath();
  	  	//FrequencySlots slots
  	        int serviceIndex = serviceAssignment.getService().getEventId();
  	      //  for (int i = 0; i < 6 ; i++ ) {
  	           // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
  	            for (Link2 edge : path) {
  	            //    LinkImplementation sdmEdge = (LinkImplementation) edge;
  	                for (int slotIndex=serviceAssignment.getStartIndex();
  	                        slotIndex<=serviceAssignment.getStartIndex()+serviceAssignment.getService().getRequiredWaveNum()-2;
  	                      slotIndex++) {
  	                
  	                

  	    	 List<CoreSC> coreSCList = serviceAssignment.getCores();
  	         List<Integer> occupiedIndexes = serviceAssignment.getConnections();
  	         
	           List<LinkCores> sdmCorelist = edge.getCoreList();
;
	      	     for (LinkCores sdmCore : sdmCorelist) {


  	    //        if (sdmCore != null){
  	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();
  	              
      	                    if (wavelengths.get(slotIndex).getSlotIndex()==slotIndex && !wavelengths.get(slotIndex).getIsOccupied()) {//||
  	                          //  wavelengths.get(slotIndex).getWaveServiceId() != serviceIndex) {
  	                  
  	                    
  	                    	// If the service is successfully assigned when the service happens
  	                        throw new RuntimeException("Since the service does not occupy the corresponding resources, the service is released.\n" + 
  	                        		"！");
  	                   }
  	                
  	                    wavelengths.get(slotIndex).setOccupiedServiceIndex(0);;

  	                    
  	      
  	            }
  	  }
  	            }
    }
    public void handleAllocationFail(Service blockedService, int index) {
    	  
        addBlockedService(blockedService);
        //  System.out.println(getBlockedServices().size());
    

  //  	}
    }*/


	

	public static void main(String[] args) {

		
	}

	

}
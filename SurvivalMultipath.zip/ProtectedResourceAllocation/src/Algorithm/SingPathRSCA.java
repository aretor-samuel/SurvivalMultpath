package Algorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.KShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.shortestpath.KShortestPaths;
import org.jgrapht.alg.util.Pair;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.common.collect.Lists;

import Network.CoreSC;
import Network.FrequencySlots;
import Network.Link2;
import Network.LinkCores;
import Network.Node2;
import Network.NodeIdImplement;
import Network.TopologySetup;
import Algorithm.BaseAlgorithm;
import TrafficGeneration.Service;
import TrafficGeneration.ServiceAssignment;
import TrafficGeneration.Timestamp;

public class SingPathRSCA extends FirstFit{
    private static final Logger log = LoggerFactory.getLogger(SingPathRSCA.class);


	
    private SimpleWeightedGraph<Node2, Link2> graph;
    final int k;
    private Set<Integer>vertexes;
    public static ArrayList<Integer>noCrosstalkSpectrumBlock=Lists.newArrayList();
    // ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

     public static List<CoreSC> coreSCList=Lists.newArrayList();

	
	private DijkstraShortestPath<Node2, Link2> dijkstraShortestPath;
    private KShortestPathAlgorithm<Node2, Link2> kShortestPathAlgorithm;
    private int weightedCount=0;
    private int defaultCount=0;
    private int samePathCount=0;
    private int bothBlockCount=0;

public  SingPathRSCA(int k,
		//Set<Integer>vertexes,
        //double alpha,
        final ArrayList<Service> service,
        final ArrayList<Timestamp> serviceTimestamp,
        final SimpleWeightedGraph<Node2, Link2> graph) {
	super(  service,serviceTimestamp, graph);
	dijkstraShortestPath = new DijkstraShortestPath<>(graph);
	kShortestPathAlgorithm = new KShortestPaths<>(graph, k);
this.k=k;
this.vertexes=vertexes;
	//public void Execute() {
}
	
	public void Execute() {
		

	    Calendar predictionTimePoint = Calendar.getInstance();
	        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

	        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
	            Timestamp timestamp = getServicesOrderedQueue().get(index);
	            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

	
	
	            if (timestamp.isStartTime()) {
	            		
     	  Node2 src = new Node2(serviceToBeAssigned.getSource());
         Node2 dst = new Node2(serviceToBeAssigned.getDestination());
         
         GraphPath<Node2, Link2> BackupPath = dijkstraShortestPath.getPath(src, dst);
         Pair<Integer,  List<Link2>> BackupPathResources= FindPathNoCrosstalkResourcesFirstAvailable( BackupPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());

         
         
         GraphPath<Node2, Link2> SinglePaths = dijkstraShortestPath.getPath(src, dst);

        	 Pair<Integer,  List<Link2>> SinglePathResources= FindPathNoCrosstalkResourcesFirstAvailable(



        			 SinglePaths.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());
       
        Pair<Integer, List<Link2>> BetterMultiPath=compare(BackupPathResources , SinglePathResources);
							
            if (BetterMultiPath.getFirst() != BaseAlgorithm.UNAVAILABLE) {


	              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
	                    	
	         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

	            assignMulticasSpetrumResource1(serviceToBeAssigned, BetterMultiPath.getFirst(), noCrosstalkSpectrumBlock, coreSCList,  BetterMultiPath.getSecond());
	      //	   System.out.println("**********************************Allocate pasedservices********************1111111111");


	                     } 
	                     
	                     else {
	                 	
	                     handleAllocationFail(serviceToBeAssigned , index);
	     //  	  System.out.println("**********************************handleBlockedservices*************************4444444");

	                 }
   	//	 System.out.println(weightedPaths.get(0).getEdgeList().toString());

	            } else {
	            	// If it is a business departure event
	               // return releaseService(serviceToBeAssigned);
	                handleServiceLeave(serviceToBeAssigned.getEventId());
   //System.out.println("**********************************handle pasedservices*************************88888*2");
	                

	            }
	            
	        }  
	    }
	
	
  
 /**   * Compare the merits of the two paths calculated by the minimum hop count and the minimum weight.
  * @param defaultPath
  * @param defaultSubscript
  * @param weightedPath
  * @param weightedSubscript
  * @return
  */

private Pair<Integer,  List<Link2>> compare(Pair<Integer,  List<Link2>> BacKupPath, Pair<Integer,  List<Link2>> MultiPath) {

if (MultiPath.getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() != BaseAlgorithm.UNAVAILABLE) {
    
    
	   return	   new Pair<>(MultiPath.getFirst(), MultiPath.getSecond());
}
 if (MultiPath.getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()== BaseAlgorithm.UNAVAILABLE) {
	
	
	return	   new Pair<>(MultiPath.getFirst(), MultiPath.getSecond());
}
	
 if (MultiPath.getFirst() == BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() == BaseAlgorithm.UNAVAILABLE) {
	return	   new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond());

		
	}
 if (MultiPath.getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() != BaseAlgorithm.UNAVAILABLE) {
	return	   new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond());
}

else {
	return	new Pair<>(MultiPath.getFirst(), MultiPath.getSecond());
 
	}

}


 






	 
	
	
	/***
    public boolean handleServiceLeave(int leaveServiceIndex) {
        if (getCurrentServices().containsKey(leaveServiceIndex)) {
            ServiceAssignment<Link2> serviceAssignment = getCurrentServices().get(leaveServiceIndex);
         //  releaseService(serviceAssignment.getService());
          releaseService1(serviceAssignment);
        //   releaseService12(serviceAssignment);

            putPassedService(
                    removeCurrentService(leaveServiceIndex));
        //   System.out.println(getPassedServices().size());
        } else if (getBlockedServices().containsKey(leaveServiceIndex)){
            // TODO
            // Actually, there is nothing to do here. Just for readability.
        } else {
            throw new RuntimeException("The leave service belongs to neither assigned services, nor blocked services.");
        }
		return true;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////
    private void releaseService1(ServiceAssignment<Link2> serviceAssignment) {
    	
  	  List<Link2> path = serviceAssignment.getPath();
  	  	//FrequencySlots slots
  	        int serviceIndex = serviceAssignment.getService().getEventId();
  	      //  for (int i = 0; i < 6 ; i++ ) {
  	           // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
  	            for (Link2 edge : path) {
  	            //    LinkImplementation sdmEdge = (LinkImplementation) edge;
  	                for (int slotIndex=serviceAssignment.getStartIndex();
  	                        slotIndex<=serviceAssignment.getStartIndex()+serviceAssignment.getService().getRequiredWaveNum()-2;
  	                      slotIndex++) {
  	                
  	                

  	    	 List<CoreSC> coreSCList = serviceAssignment.getCores();
  	         List<Integer> occupiedIndexes = serviceAssignment.getConnections();
  	         
	           List<LinkCores> sdmCorelist = edge.getCoreList();
;
	      	     for (LinkCores sdmCore : sdmCorelist) {


  	    //        if (sdmCore != null){
  	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();
  	              
      	                    if (wavelengths.get(slotIndex).getSlotIndex()==slotIndex && !wavelengths.get(slotIndex).getIsOccupied()) {//||
  	                          //  wavelengths.get(slotIndex).getWaveServiceId() != serviceIndex) {
  	                  
  	                    
  	                    	// If the service is successfully assigned when the service happens
  	                        throw new RuntimeException("Since the service does not occupy the corresponding resources, the service is released.\n" + 
  	                        		"！");
  	                   }
  	                
  	                    wavelengths.get(slotIndex).setOccupiedServiceIndex(0);;

  	                    
  	      
  	            }
  	  }
  	            }
    }
    public void handleAllocationFail(Service blockedService, int index) {
    	  
        addBlockedService(blockedService);
        //  System.out.println(getBlockedServices().size());
    

  //  	}
    }*/


	

	public static void main(String[] args) {

		
	}

	

}
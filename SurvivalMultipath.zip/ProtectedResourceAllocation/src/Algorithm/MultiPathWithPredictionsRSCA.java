package Algorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.KShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.shortestpath.KShortestPaths;
import org.jgrapht.alg.util.Pair;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import Network.CoreSC;
import Network.FrequencySlots;
import Network.Link2;
import Network.LinkCores;
import Network.Node2;
import Network.NodeIdImplement;
import Algorithm.BaseAlgorithm;
import TrafficGeneration.Service;
import TrafficGeneration.ServiceAssignment;
import TrafficGeneration.Timestamp;
import Utility.Debug;

public class MultiPathWithPredictionsRSCA extends FirstFit{
    private static final Logger log = LoggerFactory.getLogger(MultiPathWithPredictionsRSCA.class);


    public static double mape;

    public static int predictionIntervalInMins =30;
    public static int printtime =60*60*1000;

    static final int minToMs = 60*1000;
    private Map<Link2, Double> futureMap;
    private  Map<Link2, Pair<LinkCores, Double>> futureMap1; 

    private SimpleWeightedGraph<Node2, Link2> graph;
    final int k;
    final double alpha;

    private Set<Integer>vertexes;
    public static ArrayList<Integer>noCrosstalkSpectrumBlock=Lists.newArrayList();
    // ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

     public static List<CoreSC> coreSCList=Lists.newArrayList();

	
	private DijkstraShortestPath<Node2, Link2> dijkstraShortestPath;
    private KShortestPathAlgorithm<Node2, Link2> kShortestPathAlgorithm;

public  MultiPathWithPredictionsRSCA(int k,
		//Set<Integer>vertexes,
        double alpha,
        final ArrayList<Service> service,
        final ArrayList<Timestamp> serviceTimestamp,
        final SimpleWeightedGraph<Node2, Link2> graph) {
	super(  service,serviceTimestamp, graph);
	dijkstraShortestPath = new DijkstraShortestPath<>(graph);
	kShortestPathAlgorithm = new KShortestPaths<>(graph, k);
this.k=k;
this.alpha=alpha;

this.vertexes=vertexes;
	//public void Execute() {
}
	
	public void Execute() {
		

	    Calendar predictionTimePoint = Calendar.getInstance();
	        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

	        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
	            Timestamp timestamp = getServicesOrderedQueue().get(index);
	            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

	           while (timestamp.getTime().after(predictionTimePoint)) {
	                // Move the time backwards by a predicted time interval)
	                predictionTimePoint.setTimeInMillis(predictionTimePoint.getTimeInMillis() + predictionIntervalInMins*minToMs);
	                List<Timestamp> future = subList(getServicesOrderedQueue(), index);
	             // Get future load conditions
	                futureMap1 = generateOccupiedSlotsNum1(future);
	            }

	            // Introduce the squared mean error)
	            futureMap1 = introduceMAPE1(futureMap1, mape);
	        //   int FuturerequireWaveNum= CompareRquredSlots(futureMap, serviceToBeAssigned.getRequiredWaveNum());
	           // int FuturerequireWaveNum=BaseAlgorithm.UNAVAILABLE;
	            // if this timestamp is start-time.
	            if (timestamp.isStartTime()) {
	            		
     	  Node2 src = new Node2(serviceToBeAssigned.getSource());
         Node2 dst = new Node2(serviceToBeAssigned.getDestination());
         GraphPath<Node2, Link2> BackupPath = dijkstraShortestPath.getPath(src, dst);
         Pair<Integer,  List<Link2>> BackupPathResource= FindPathNoCrosstalkResourcesFirstAvailable( BackupPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());

         
         
         updateWeight1(futureMap1);

         List<GraphPath<Node2, Link2>> weightedPaths = kShortestPathAlgorithm.getPaths(src, dst);
//		 System.out.println(weightedPaths.get(0).getEdgeList().toString());


      //  Pair<Integer,  List<Link2>> AvailablePath= FindPathNoCrosstalkResourcesFirstAvailable41( weightedPaths,  serviceToBeAssigned.getRequiredWaveNum());
    //    Pair<Integer,  List<Link2>> AvailablePath= FindPathNoCrosstalkResourcesFirstAvailable55( weightedPaths,  serviceToBeAssigned.getRequiredWaveNum());

        //     Pair<Integer,  List<Link2>> AvailablePath= FindPathNoCrosstalkResourcesFirstAvailable3( weightedPaths,  serviceToBeAssigned.getRequiredWaveNum());
       //  int startIdex= FindPathNoCrosstalkResourcesFirstAvailable4( weightedPaths,  serviceToBeAssigned.getRequiredWaveNum());
        
        weightedPaths.sort(new Comparator<GraphPath<Node2, Link2>>() {
            @Override
            public int compare(GraphPath<Node2, Link2> o1, GraphPath<Node2, Link2> o2) {
                if (o1.getLength() > o2.getLength()) {
                    return 1;
                } else if (o1.getLength() < o2.getLength()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });
        List<Pair<Integer,  List<Link2>>> CandidatePaths = Lists.newArrayListWithExpectedSize(weightedPaths.size());
        for (GraphPath<Node2, Link2> weightedPath : weightedPaths) {
      //  int weightedSubscript = FindPathNoCrosstalkResourcesFirstAvailable5(
                //   int weightedSubscript = FindPathNoCrosstalkResourcesFirstAvailable2(
                 //      int weightedSubscript = FindPathNoCrosstalkResourcesFirstAvailable3(
        	 Pair<Integer,  List<Link2>> AvailablePath= FindPathNoCrosstalkResourcesFirstAvailable(



                    weightedPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());
        	 CandidatePaths.add(AvailablePath);
        }
        List<Pair<Integer, List<Link2>>> BetterMultiPath=compare(BackupPathResource , CandidatePaths);
		
        //if (BetterMultiPath.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE) {


              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
                    	
         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

           // assignMulticasSpetrumResource1(serviceToBeAssigned, BetterMultiPath.get(0).getFirst(), noCrosstalkSpectrumBlock, coreSCList,  BetterMultiPath.get(0).getSecond());
      //	   System.out.println("**********************************Allocate pasedservices********************1111111111");


							
            if (CandidatePaths.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE) {


	              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
	                    	
	         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

	           assignMulticasSpetrumResource1(serviceToBeAssigned, CandidatePaths.get(0).getFirst(), noCrosstalkSpectrumBlock, coreSCList,  CandidatePaths.get(0).getSecond());
	      //	   System.out.println("**********************************Allocate pasedservices********************1111111111");
            }
	           else  if (CandidatePaths.get(1).getFirst() != BaseAlgorithm.UNAVAILABLE) {


		              //       if (startIdex != BaseAlgorithm.UNAVAILABLE) {
		                    	
		         	 //     assignMulticasSpetrumResource2(serviceToBeAssigned, startIdex, noCrosstalkSpectrumBlock, coreSCList,  weightedPaths);

		           assignMulticasSpetrumResource1(serviceToBeAssigned, CandidatePaths.get(1).getFirst(), noCrosstalkSpectrumBlock, coreSCList,  CandidatePaths.get(1).getSecond());
		      //	   System.out.println("**********************************Allocate pasedservices***********

	                     } 
	                     
	                     else {
	                 	
	                     handleAllocationFail(serviceToBeAssigned , index);
	      //   	  System.out.println("**********************************handleBlockedservices*************************4444444");

	                 }
   	//	 System.out.println(weightedPaths.get(0).getEdgeList().toString());

	            } else {
	            	// If it is a business departure event
	               // return releaseService(serviceToBeAssigned);
	                handleServiceLeave(serviceToBeAssigned.getEventId());
  //  System.out.println("**********************************handle pasedservices*************************88888*2");
	                

	            }
	            
	        }  
	    }
	        
	        
	    	        
	        /**   * Compare the merits of the two paths calculated by the minimum hop count and the minimum weight.
	         * @param defaultPath
	         * @param defaultSubscript
	         * @param weightedPath
	         * @param weightedSubscript
	         * @return
	         */

	        private List<Pair<Integer, List<Link2>>> compare(Pair<Integer,  List<Link2>> BacKupPath ,List<Pair<Integer,  List<Link2>>> MultiPath) {
	   	     List<Pair<Integer,  List<Link2>>> CandidatePaths = Lists.newArrayListWithExpectedSize(MultiPath.size());

	   	 
	   	     if (MultiPath.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst() != BaseAlgorithm.UNAVAILABLE) {
	   	    	    
	   	    	    
	   	  	   	     
	   	    	 CandidatePaths.add(new Pair<>(MultiPath.get(0).getFirst(), MultiPath.get(0).getSecond()));
	   	  			 return CandidatePaths;
	   	  }
	   	  else if (MultiPath.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()== BaseAlgorithm.UNAVAILABLE) {
	   	  	
	   		  CandidatePaths.add(new Pair<>(MultiPath.get(0).getFirst(), MultiPath.get(0).getSecond()));
	   	  	return	CandidatePaths;   
	   	  }//return directly)
	   	  else if (MultiPath.get(0).getFirst() == BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()!= BaseAlgorithm.UNAVAILABLE) {
	   		  	
	   		  CandidatePaths.add(new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond()));
	   	  	return	CandidatePaths;   
	   	  }//return directly)
	   	  else if (MultiPath.get(0).getFirst() == BaseAlgorithm.UNAVAILABLE && BacKupPath.getFirst()== BaseAlgorithm.UNAVAILABLE) {
	   		  	
	   		  CandidatePaths.add(new Pair<>(BacKupPath.getFirst(), BacKupPath.getSecond()));
	   	  	return	CandidatePaths;   
	   	  }//return di
	   	  else {
	   		  CandidatePaths.add(new Pair<>(MultiPath.get(0).getFirst(), MultiPath.get(0).getSecond()));
	   		  	return	CandidatePaths;   

	   	  }
	   }	
   /** public boolean handleServiceLeave(int leaveServiceIndex) {
        if (getCurrentServices().containsKey(leaveServiceIndex)) {
            ServiceAssignment<Link2> serviceAssignment = getCurrentServices().get(leaveServiceIndex);
         //  releaseService(serviceAssignment.getService());
          releaseService1(serviceAssignment);
        //   releaseService12(serviceAssignment);

            putPassedService(
                    removeCurrentService(leaveServiceIndex));
        //   System.out.println(getPassedServices().size());
        } else if (getBlockedServices().containsKey(leaveServiceIndex)){
            // TODO
            // Actually, there is nothing to do here. Just for readability.
        } else {
            throw new RuntimeException("The leave service belongs to neither assigned services, nor blocked services.");
        }
		return true;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////
    private void releaseService1(ServiceAssignment<Link2> serviceAssignment) {
    	
  	  List<Link2> path = serviceAssignment.getPath();
  	  	//FrequencySlots slots
  	        int serviceIndex = serviceAssignment.getService().getEventId();
  	      //  for (int i = 0; i < 6 ; i++ ) {
  	           // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
  	            for (Link2 edge : path) {
  	            //    LinkImplementation sdmEdge = (LinkImplementation) edge;
  	                for (int slotIndex=serviceAssignment.getStartIndex();
  	                        slotIndex<=serviceAssignment.getStartIndex()+serviceAssignment.getService().getRequiredWaveNum()-2;
  	                      slotIndex++) {
  	                
  	                

  	    	 List<CoreSC> coreSCList = serviceAssignment.getCores();
  	         List<Integer> occupiedIndexes = serviceAssignment.getConnections();
  	         
	           List<LinkCores> sdmCorelist = edge.getCoreList();
;
	      	     for (LinkCores sdmCore : sdmCorelist) {


  	    //        if (sdmCore != null){
  	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();
  	              
      	                    if (wavelengths.get(slotIndex).getSlotIndex()==slotIndex && !wavelengths.get(slotIndex).getIsOccupied()) {//||
  	                          //  wavelengths.get(slotIndex).getWaveServiceId() != serviceIndex) {
  	                  
  	                    
  	                    	// If the service is successfully assigned when the service happens
  	                        throw new RuntimeException("Since the service does not occupy the corresponding resources, the service is released.\n" + 
  	                        		"！");
  	                   }
  	                
  	                    wavelengths.get(slotIndex).setOccupiedServiceIndex(0);;

  	                    
  	      
  	            }
  	  }
  	            }
    }
    public void handleAllocationFail(Service blockedService, int index) {
    	  
        addBlockedService(blockedService);
        //  System.out.println(getBlockedServices().size());
    

  //  	}
    }
    */
    protected  Map<Link2, Pair<LinkCores, Double>> generateOccupiedSlotsNum1(List<Timestamp> orderedList) {

        // initialize occupiedSlotsNum
    //	Map<Link2, Double> occupiedSlotsNum = Maps.newHashMap();
       // for (Link2 edge : getGraph().edgeSet()) {
        //    occupiedSlotsNum.put(edge, 0.0d);
         //   occupiedSlotsNum.put(edge, (double) edge.getCoreList().get(0).getWavelength().size());
            Map<Link2, Pair<LinkCores, Double>>occupiedSlotsNum = Maps.newHashMap();
            for (Link2 edge : getGraph().edgeSet()) {
            	List<LinkCores>sdmCores=edge.getCoreList();
				// for (int j=0; j<sdmCores.size(); j++) {
				 LinkCores linkcores=sdmCores.get(0);
				// occupiedSlotsNum.put(edge, <linkcores, 0.0>);
			      //  serviceEventInfo.put(serviceEvent, new Pair<List<CoreSC>, List<Integer>>(coreScPerEdgeList, finalResult));
			        occupiedSlotsNum.put(edge, new Pair<LinkCores, Double>(linkcores, 0.0));



        }

        // collect current services
        for (ServiceAssignment<Link2> servAssign : getCurrentServices().values()) {
        	execFutureServiceAssignment1(occupiedSlotsNum, servAssign.getPath(), true, servAssign.getService().getRequiredWaveNum());
        }

        // collect future services
        // key represents service index, value represents path of services
        Map<Integer, List<Link2>> futureService = Maps.newHashMap();
        for (int i=0; i<orderedList.size(); i++) {
            List<Link2> path;
            Timestamp timestamp = orderedList.get(i);
            int serviceIndex = timestamp.getServiceIndex();
            if (timestamp.isStartTime()) {
                Service service = getServicesQueue().get(serviceIndex-1);
                path = dijkstraShortestPath.getPath( new Node2(service.getSource()), new Node2(service.getDestination())).getEdgeList();
                futureService.put(serviceIndex, path);
                execFutureServiceAssignment1(occupiedSlotsNum, path, true, service.getRequiredWaveNum());
            } else {
                int requiredSlotsNum = 0;
                if (getCurrentServices().containsKey(serviceIndex)) {
                    path = getCurrentServices().get(serviceIndex).getPath();
                    requiredSlotsNum = getServicesQueue().get(serviceIndex-1).getRequiredWaveNum();
                } else if (futureService.containsKey(serviceIndex)) {
                    path = futureService.get(serviceIndex);
                    // must be serviceIndex-1
                    requiredSlotsNum = getServicesQueue().get(serviceIndex-1).getRequiredWaveNum();
                    futureService.remove(serviceIndex);
                } else if (getBlockedServices().containsKey(serviceIndex)) {
                    // Do nothing.
                    path = null;
                } else {
                    throw new RuntimeException(
                            "service which neither belongs to current services nor future services leaves.");
                }
                execFutureServiceAssignment1(occupiedSlotsNum, path, false, requiredSlotsNum);

            }
        }

        if (Debug.ENABLE_DEBUG) {
            checkNoLessThanZero1(occupiedSlotsNum);
        }
        return occupiedSlotsNum;
    }
	//  protected void checkNoLessThanZero(Map<Link2, Double> occupiedSlotsNum) {
 protected void checkNoLessThanZero1(Map<Link2, Pair<LinkCores, Double>>occupiedSlotsNum) {
     for (Link2 edge : occupiedSlotsNum.keySet()) {
    	 double d=occupiedSlotsNum.get(edge).getSecond();
	     //   for (double d : occupiedSlotsNum.values()) {
	            if (d < 0 ) {
	                throw new RuntimeException("less than zero!");
	            }
	        }
	    }

//  protected void execFutureServiceAssignment(Map<Link2, Double> occupiedSlotsNum,
 protected void execFutureServiceAssignment1(Map<Link2, Pair<LinkCores, Double>>occupiedSlotsNum,

              List<Link2> path, boolean isPlus, int requiredSlotsNum) {
          if (path != null) {
            if (isPlus) {
               for (Link2 edge : path) {
              int num = requiredSlotsNum;
          	List<LinkCores>sdmCores=edge.getCoreList();
				// for (int j=0; j<sdmCores.size(); j++) {
				 LinkCores linkcores=sdmCores.get(0);
			
            // occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge) + num);
            // occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge). + num);
		        occupiedSlotsNum.put(edge, new Pair<LinkCores, Double>(occupiedSlotsNum.get(edge).getFirst(),occupiedSlotsNum.get(edge).getSecond()+ num));

          


         }
       } else {
      for (Link2 edge : path) {
       int num = requiredSlotsNum;
    //   occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge) - num);
       List<LinkCores>sdmCores=edge.getCoreList();
		// for (int j=0; j<sdmCores.size(); j++) {
		 LinkCores linkcores=sdmCores.get(0);
	
   // occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge) + num);
   // occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge). + num);
       occupiedSlotsNum.put(edge, new Pair<LinkCores, Double>(occupiedSlotsNum.get(edge).getFirst(),occupiedSlotsNum.get(edge).getSecond()- num));


  //     occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge) - num);
     }
    }
} else {
// blocked service leave, do nothing.
}
}

  protected List<Timestamp> subList(ArrayList<Timestamp> total, int index) {

      Calendar tmp = Calendar.getInstance();
      tmp.setTimeInMillis(total.get(index).getTime().getTimeInMillis() + predictionIntervalInMins*minToMs);

      int end = index+1;
      while (total.get(end).getTime().before(tmp)) {
          end++;
          if (end == total.size()) {
              break;
          }
      }
      if (end == index+1) {
          throw new RuntimeException("only one or no service between predictionInterval.");
      }
      /* Returns a view of the portion of this list between the specified
         {@code fromIndex}, inclusive, and {@code toIndex}, exclusive. */
      List<Timestamp> list = total.subList(index, end);
      return list;

  }

  public  Map<Link2, Pair<LinkCores, Double>> introduceMAPE1( Map<Link2, Pair<LinkCores, Double>> futureMap2, double mape) {

      Map<Link2, Pair<LinkCores, Double>>occupiedSlotsNum = Maps.newHashMap();

      assert mape >=0 && mape <=1;
      if (mape == 0) {
          return futureMap2;
      }
      Map<Link2, Double> rtn = Maps.newHashMap();

  //    for (Map.Entry<Link2, Double> entry : futureMap2.entrySet()) {
          for (Map.Entry<Link2,  Pair<LinkCores, Double>> entry : futureMap2.entrySet()) {

          double value = entry.getValue().getSecond();
          double diff = value * Math.random() * mape * 2; //The amplitude of the left and right swing should be (-mape*2, mape*2)
          if (Math.random() > 0.5) {
              value = value + diff;
          } else {
              value = value - diff;
          // value = value + diff;

          }
       //   rtn.put(entry.getKey(), value);
      //    rtn.put(entry.getKey(), value);
	        occupiedSlotsNum.put(entry.getKey(), new Pair<LinkCores, Double>(entry.getValue().getFirst(), value));


      }
      return occupiedSlotsNum;
  }
  private void updateWeight1(Map<Link2, Pair<LinkCores, Double>> weights) {
  	
      
      for (Map.Entry<Link2,  Pair<LinkCores, Double>> entry : weights.entrySet()) {
          double p  = entry.getValue().getSecond();
         double c = entry.getValue().getFirst().occupiedSlotsNum();
          // has no log(d+1) as the denominator here.)
          double edgeWeight = c+alpha*p;
          getGraph().setEdgeWeight(entry.getKey(), edgeWeight);
      }
  }

	

	public static void main(String[] args) {

		
	}

	

}
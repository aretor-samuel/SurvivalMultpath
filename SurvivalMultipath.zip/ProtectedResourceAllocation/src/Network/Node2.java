package Network;


import com.google.common.base.MoreObjects;

import java.io.Serializable;

/**
 * Vertex class in EON including index and boolean value judging whether it runs normally.
 * Created by yby on 2017/3/31.
 */
public class Node2 implements Serializable {
    private int index;
    private boolean isRunning;

    public Node2(int index, boolean isRunning) {
        this.index = index;
        this.isRunning = isRunning;
    }

    public Node2(int index) {
        this.index = index;
        this.isRunning = true;
    }

    public int getIndex() {
        return index;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public void setIsRunning(boolean isRunning) {
        this.isRunning = isRunning;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Node2 eonVertex = (Node2) o;

        return index == eonVertex.index;

    }

    @Override
    public int hashCode() {
        return index;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("index", index)
                .toString();
    }
}

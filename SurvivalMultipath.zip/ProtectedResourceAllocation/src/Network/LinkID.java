package Network;


/**
 * Created by samBabel on 2019-05-16.
 * Link identity.
 * Normally, we identity a link by its src and dst, but this rule is not satisfied for all different types of edges. So,
 * it is better to create specific interface to describe link id .
 */
public interface LinkID {

    /**
     * The reason why I put this attribute in EdgeId is because the judgement about equality of two EdgeId instances
     * depends on whether this link is directed.
     * @return
     */
    boolean isDirected();
}


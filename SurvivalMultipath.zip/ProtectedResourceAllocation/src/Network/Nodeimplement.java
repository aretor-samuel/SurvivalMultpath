package Network;


import com.google.common.base.MoreObjects;

import java.io.Serializable;

/**
 * Node Class is created check whether its on or not
 * Created by babel on 2019/05/12.
 */
/**
public class Nodeimplement implements Serializable {
    private int index;
    private boolean isON;

    public Nodeimplement(int index, boolean isON) {
        this.index = index;
        this.isON = isON;
    }

    public Nodeimplement(int index) {
        this.index = index;
        this.isON = true;
    }

    public int getIndex() {
        return index;
    }

    public boolean isON() {
        return isON;
    }

    public void setIsRunning(boolean isON) {
        this.isON = isON;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Nodeimplement node = (Nodeimplement) o;

        return index == node.index;

    }

    @Override
    public int hashCode() {
        return index;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("index", index)
                .toString();
    }
}
////////////////////////////////////////////////////////////////*/


import Network.Node;
import Network.NodeId;
import Network.NodeStatus;
import Utility.WeightType;

//import Network.NodeType;
//import Networkutils.Error;
//import Network.WeightType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by Boyuan on 16-11-13.
 * require ： Node接口的Sdm网络Node实现类
 */
public class Nodeimplement implements Serializable, Node {

    private static final Logger log = LoggerFactory.getLogger(Nodeimplement.class);

    //  make it final because there is only router in ip address for simply.
    private final NodeType type = NodeType.ROUTER;

    private NodeStatus status = NodeStatus.DOWN;

    private NodeId id;

    private Map<WeightType, Double> weights;

    public Map<WeightType, Double> getWeights() {
        return weights;
    }


    public void addWeight(WeightType type, double value) {
        if (weights.get(type) != null) {
         //   log.info("更改点权 {} 的值，从 {} 改为 {}。", type, weights.get(type), value);
            log.info("更改点权 {} 的值，从 {} 改为 {}。", weights.get(type), value);

        }
        weights.put(type, value);
    }

    /**
     * The constructor method is private, just open for internal bulder.
     * @param id node id
     * @param status node status
     */
    private Nodeimplement(NodeId id, NodeStatus status) {
        this.id = id;
        this.status = status;

        this.weights = new HashMap<WeightType, Double>();
        this.weights.put(WeightType.HOP_WEIGHT, Node.hopWeight);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Nodeimplement sdmNode = (Nodeimplement) o;

        if (type != sdmNode.type) return false;
        if (status != sdmNode.status) return false;
        if (!id.equals(sdmNode.id)) return false;
        return weights.equals(sdmNode.weights);

    }

    @Override
    public int hashCode() {
        int result = type.hashCode();
        result = 31 * result + status.hashCode();
        result = 31 * result + id.hashCode();
        result = 31 * result + weights.hashCode();
        return result;
    }

    public Node deepClone() {
        return new Nodeimplement(new NodeIdImplement(((NodeIdImplement)id).getRouterId()), status);
    }

    public NodeId getNodeId() {
        return id;
    }

  //  public NodeType getNodeType() {
    //    return type;
    //}

    public NodeStatus getNodeStatus() {
        return status;
    }

    public void setNodeStatus(NodeStatus status) {
        this.status = status;
    }


    public static SdmNodeBuilder builder() {
        return new SdmNodeBuilder();
    }



    public static class SdmNodeBuilder implements NodeBuilder {

        private NodeStatus status = NodeStatus.DOWN;

        private NodeId id;

        public Node build() {
          // checkNotNull(id, Error.NODE_ID_NULL);
            return new Nodeimplement(id, status);
        }

        public Node build(NodeId nodeId, NodeStatus status) {
            return new Nodeimplement(nodeId, status);
        }

        public void setNodeStatus(NodeStatus status) {
            this.status = status;
        }

        public void setNodeId(NodeId id){
            this.id = id ;
        }

		@Override
	//	public void setNodeType(NodeType type) {
			// TODO Auto-generated method stub
			
	//	}

        public void setNodeType(NodeType type) {
            log.error("Ip device contains just one type which is called ROUTER, " +
                   "so it will be unacceptable for setting anything to replace it ");
       
    }



//	@Override
	//public double getWeight(WeightType weightType) {
		// TODO Auto-generated method stub
	//	return 0;
	//}

//	@Override
	//public void addWeight(WeightType type, double value) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public double getWeight(WeightType weightType) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public NodeType getNodeType() {
		// TODO Auto-generated method stub
		return null;
	}
}

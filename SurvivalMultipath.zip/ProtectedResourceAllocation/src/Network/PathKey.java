package Network;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sambabel
 */
public class PathKey {
    private int node1;
    private int node2;

    public int getNode1() {
        return node1;
    }

    public void setNode1(int node1) {
        this.node1 = node1;
    }

    public int getNode2() {
        return node2;
    }

    public void setNode2(int node2) {
        this.node2 = node2;
    }

    public PathKey(int node1, int node2) {
        this.node1 = node1;
        this.node2 = node2;
    }

    @Override
    public String toString() {
        return node1+"-->"+node2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PathKey)) return false;

        PathKey pathKey = (PathKey) o;

        if (node1 != pathKey.node1) return false;
        return node2 == pathKey.node2;

    }

    @Override
    public int hashCode() {
        int result = node1;
        result = 31 * result + node2;
        return result;
    }

    public void sort(){
        if(node1>node2){
            int temp=node1;
            node1=node2;
            node2=temp;
        }
    }
    
}

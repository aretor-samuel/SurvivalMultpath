package Network;

import com.google.common.base.MoreObjects;
import Network.LinkID;
import Network.LinkCores;

/**
 * Created by asia on 2019/05/24.
* This class represents the value of the spectral renormality of the specified core of the specified edge at a certain time. The coreSC can find the moment, the edge and the core of the side where it is located.
 */
public class CoreSC {

    // 某个时刻的信息
    private double time;
    // 表示核所属的edge
    private LinkID edgeId;

    // 表示核的编号
    private int coreIndex;
    // 表示该核上的SC值
    private double sc;
	private int edgeId1;
	private Link2 link;

    public CoreSC() {

    }
    public CoreSC(double time, int edgeId1, int coreIndex, double sc) {

  //  public CoreSC(double time, Link2 link, int coreIndex, double sc) {
        this.time = time;
        this.link = link;
        this.edgeId = edgeId;
        this.edgeId1 = edgeId1;

        this.coreIndex = coreIndex;
        this.sc = sc;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }
    public int getEdgeId1() {
        return edgeId1;
    }
    public Link2 getLinkId() {
        return link;
    }

    public LinkID getEdgeId() {
        return edgeId;
    }
    public void setEdgeId2(Link2 link) {
        this.link = link;
    }

    public void setEdgeId1(int edgeId) {
        this.edgeId1 = edgeId1;
    }
    public void setEdgeId(LinkID edgeId) {
        this.edgeId = edgeId;
    }

    public int getCoreIndex() {
        return coreIndex;
    }

    public void setCoreIndex(int coreIndex) {
        this.coreIndex = coreIndex;
    }

    public double getSc() {
        return sc;
    }

    public void setSc(double sc) {
        this.sc = sc;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CoreSC coreSC = (CoreSC) o;

        if (coreIndex != coreSC.coreIndex) return false;
        return edgeId1==coreSC.edgeId1;
     //   return link==coreSC.link;


    }

    @Override
    public int hashCode() {
        int result = edgeId.hashCode();
        result = 31 * result + coreIndex;
        return result;
    }

   // public CoreSC(LinkID edgeId, int coreIndex) {
        public CoreSC(int edgeId1, int coreIndex) {
            this.edgeId1 = edgeId1;
     //   this.edgeId = edgeId;
        this.coreIndex = coreIndex;
    }

    /**
     * toString方法被写成这样，是为了输出log信息。
     * @return
     */
    @Override
    public String toString() {
      //  return Objects.toStringHelper(this)
        return MoreObjects.toStringHelper(this)
                .add("edgeId", edgeId)
                .add("coreIndex", coreIndex)
                .toString();
    }
}

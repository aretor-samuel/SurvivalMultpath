package Network;
import static com.google.common.base.Preconditions.checkNotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;

import org.jgrapht.graph.DefaultWeightedEdge;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;


import Utility.Error;
import Utility.LinkType;
import Utility.WeightType;



public class Link2 extends DefaultWeightedEdge implements Serializable{
	private List<LinkCores> coreList  = new ArrayList<LinkCores>(7);
    private ArrayList<FrequencySlots> slots;
	private Node2 src;
	private Node2 dst;
	private LinkStatus status;
	private int id;
	 public int getEdgeId() {
	        return id;
	    }

    public ArrayList<FrequencySlots> getSlots() {
        return slots;
    }

    public Node2 getSource() {
        return (Node2) super.getSource();
    }

    public Node2 getDestination() {
        return (Node2) super.getTarget();
    }
    public List<LinkCores> getCoreList() {
        checkNotNull(coreList, "core in graph should not be null.");
        return coreList;
    }
    public TreeSet<Integer> availableSlotsIndexSet() {
        TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();

        for (FrequencySlots slot : slots) {
            if (!slot.getIsOccupied()) {
                availableSlotsIndex.add(slot.getSlotIndex());
            }
        }
        return availableSlotsIndex;
    }

    /**
     * get the array list of available slots index by ascend.
     * @return set
     */
    public ArrayList<Integer> availableSlotsIndexList() {
        ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();
        for (FrequencySlots slot : slots) {
            if (!slot.getIsOccupied()) {
                availableSlotsIndex.add(slot.getSlotIndex());
            }
        }
        return availableSlotsIndex;
    }
    public ArrayList<Integer> availableSlotsIndexList(List<CoreSC> maxCoreScPerEdge,ArrayList<Integer>noCrosstalkslots) {
        ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();
	 for (int j=0; j<maxCoreScPerEdge.size(); j++) {

       LinkCores sdmcores= coreList.get(maxCoreScPerEdge.get(j).getCoreIndex());
       //  for (LinkCores sdmcores : coreList) {

			 for (int i=0; i<noCrosstalkslots.size(); i++) {

        	List<FrequencySlots> wavelength=sdmcores.getWavelength();
        	
           // if (!slot.getIsOccupied()) {
        if (!wavelength.get(i).getIsOccupied()) {

                availableSlotsIndex.add(i);
            }
        }
        }
        return availableSlotsIndex;
    }
   // public TreeSet<Integer> availableSlotsIndexSet(ArrayList<Integer>noCrosstalkslots) {
       public TreeSet<Integer> availableSlotsIndexSet(List<CoreSC> maxCoreScPerEdge,ArrayList<Integer>noCrosstalkslots) {

    
        TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();
       for (int j=0; j<maxCoreScPerEdge.size(); j++) {

            LinkCores sdmcores= coreList.get(maxCoreScPerEdge.get(j).getCoreIndex());


     //   for (LinkCores sdmcores : coreList) {
        	 for (int i=0; i<noCrosstalkslots.size(); i++) {

             	List<FrequencySlots> wavelength=sdmcores.getWavelength();
             	
                // if (!slot.getIsOccupied()) {
             if (!wavelength.get(i).getIsOccupied()) {

                     availableSlotsIndex.add(i);
                 }
        }
        }
        return availableSlotsIndex;
    }

       public int occupiedSlotsNum(List<CoreSC> maxCoreScPerEdge,ArrayList<Integer>noCrosstalkslots) {
           int count = 0;
           for (int j=0; j<maxCoreScPerEdge.size(); j++) {

               LinkCores sdmcores= coreList.get(maxCoreScPerEdge.get(j).getCoreIndex());


        //   for (LinkCores sdmcores : coreList) {
           	 for (int i=0; i<noCrosstalkslots.size(); i++) {

                	List<FrequencySlots> wavelength=sdmcores.getWavelength();
                	
                   // if (!slot.getIsOccupied()) {
                if (wavelength.get(i).getIsOccupied()) {
                   count++;
               }
           	 }
           }
           return count;
       }
       public int occupiedSlotsNum() {
           int count = 0;
           for(FrequencySlots slot : slots) {
               if (slot.getIsOccupied()) {
                   count++;
               }
           }
           return count;
       }
       public int occupiedSlotsNum1() {
           int count = 0;
       	 for (int j=0; j<coreList.size(); j++) {
        //   for (LinkCores sdmcores : coreList) {
       		LinkCores Sdmcore=coreList.get(j);
               List<FrequencySlots> wavelengths = Sdmcore.getWavelength();

               if (wavelengths.get(0).getIsOccupied()) {
                   count++;
               }
           }
           return count;
       }
       public int occupiedSlotsNum2() {
           int count = 0;
       	 for (int j=0; j<coreList.size(); j++) {
        //   for (LinkCores sdmcores : coreList) {
       		LinkCores Sdmcore=coreList.get(j);
              // List<EonSlot> wavelengths = Sdmcore.getWavelength();
       		count=Sdmcore.occupiedSlotsNum();
            //   if (wavelengths.get(0).isOccupied()) {
            //       count++;
             //  }
           }
           return count;
       }

       public ArrayList<Integer> availableSlotsIndexList1() {
           ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

         	 for (int j=0; j<coreList.size()-1; j++) {
          //   for (LinkCores sdmcores : coreList) {
         		LinkCores sdmcores=coreList.get(j);

           	List<FrequencySlots> wavelength=sdmcores.getWavelength();
   			 for (int i=0; i<wavelength.size(); i++) {

           	
              // if (!slot.getIsOccupied()) {
           if (!wavelength.get(i).getIsOccupied()) {

                   availableSlotsIndex.add(i);
               }
           }
           }
           return availableSlotsIndex;
       }
      // public TreeSet<Integer> availableSlotsIndexSet(ArrayList<Integer>noCrosstalkslots) {
          public TreeSet<Integer> availableSlotsIndexSet1() {

       
           TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();
                  //   LinkCores sdmcores= coreList.get);

      	 for (int j=0; j<coreList.size()-1; j++) {
       //   for (LinkCores sdmcores : coreList) {
      		LinkCores sdmcores=coreList.get(j);
                	List<FrequencySlots> wavelength=sdmcores.getWavelength();
      			 for (int i=0; i<wavelength.size(); i++) {

                	
                   // if (!slot.getIsOccupied()) {
                if (!wavelength.get(i).getIsOccupied()) {

                        availableSlotsIndex.add(i);
                    }
           }
      			 
           }
           return availableSlotsIndex;
       }

          public ArrayList<Integer> checkAvaiSpectrumBlockInOrderSameIndex1(   int requiredWaveNum) {
                 ArrayList<Integer> noCrosstalkSpectrumBlock=Lists.newArrayList(); ;

         //    ArrayList<Integer> avaiSpectrumBlock=Lists.newArrayList(); ;
        //	for (int j=0; j<coreList.size(); j++) {
            //	for (LinkCores sdmcores: coreList) {

        	          for (LinkCores sdmcores : coreList) {
        	    //  	LinkCores sdmcores=coreList.get(j);
        	      	//	LinkCores sdmcores=coreList.get(j);


            //     for (CoreSC coreSC:coreSCList) {
             //    LinkCores sdmCore = edge.getCoreList().get(coreSC.getCoreIndex());


                         if (sdmcores != null){
              //    first = findAvaiSpectrumBlocksInOrder1(sdmCore.getWavelength() , requiredWaveNum);
                        	  ArrayList<Integer> avaiSpectrumBlock=sdmcores.availableSlotsIndexList1();
        //return first;
                      if (avaiSpectrumBlock != null) {
                    	   noCrosstalkSpectrumBlock =
                   	                     noCrossTalkFilterSameIndex1(sdmcores, avaiSpectrumBlock, requiredWaveNum);
                      //  return null;
                      }

                   }
                   }
        return noCrosstalkSpectrumBlock;
        	}
          private  ArrayList<Integer> noCrossTalkFilterSameIndex1(LinkCores comparedCore,
                  ArrayList<Integer> avaiSpectrumBlock, int requiredWaveNum) {

        	// Find the spectrum block that will not cause crosstalk first.
        	//List<List<Integer>> tmp = avaiSpectrumBlock;
          	ArrayList<Integer> tmp = Lists.newArrayList();
       //   for (CoreSC coreSC : maxCoreScPerEdge) {
          	// Find a spectrum block on the Core that does not cause crosstalk
          	tmp = noCrossTalkFilterFurtherSameIndex2( comparedCore, avaiSpectrumBlock, requiredWaveNum);
            //  if (tmp == null || tmp.isEmpty()) {
            //      return null;
            //  }
        //  }

        // Determine the spectrum combination of the filtered spectrum blocks
          return tmp;
        }
        	private ArrayList<Integer> noCrossTalkFilterFurtherSameIndex2( LinkCores comparedCore,ArrayList<Integer> avaiSpectrumBlock, int requiredWaveNum) {

        		//LinkImplementation sdmEdge = (LinkImplementation) graph.getEdges().get(coreSC.getEdgeId());
                //Link2 sdmEdge =  graph.getEdge(src, dst);

                //LinkCores comparedCore = mapToCore(coreSC);
                        ArrayList<Integer> occupiedTime = Lists.newArrayList();

                	//	 for (int j=0; j<coreList.size()-1; j++) {
                  	       //   for (LinkCores sdmcores : coreList) {
                  	    //  		LinkCores sdmcores=coreList.get(j);
             //   LinkCores comparedCore = edge.getCoreList().get(coreSC.getCoreIndex());
              //  LinkCores comparedCore = coreList.get(j);
             //   LinkCores comparedCore = coreList.get(0);

                

                List<FrequencySlots> wavelengths = comparedCore.getWavelength();

                List<ArrayList<Integer>> rtn = new ArrayList<ArrayList<Integer>>();
                ArrayList<Integer> rtn1 = Lists.newArrayList();


                //The parameter type List<List<Integer>> is not set properly, but it has been difficult to change.
                //int waveInCoreNum = edge.getCoreList().get(0).getWavelength().size();
                //This variable occupiedTime is the dimensionality reduction of the avaiSpectrumBlock.
             //   for (List<Integer> m : avaiSpectrumBlock) {
            //	for (int j=1; j<avaiSpectrumBlock.size(); j++) {

                      for (int n : avaiSpectrumBlock) {
                   occupiedTime.add(n);
                //     occupiedTime.add(j);

                          }
                //}

                  if (comparedCore != null){
                //traversing from big to small
                    for (int i=occupiedTime.size()-2; i>=0; i--) {
                     int index = occupiedTime.get(i);
                          int count = 0;
                //Traverse the adjacent Core
                    for (LinkCores adjCore : comparedCore.getAdjacentCores()) {
             if (adjCore.getWavelength().get(index).getIsOccupied()) {
                //If the previous count value is 1, this time, the spectrum resources of the adjacent Core are occupied. Therefore, crosstalk is generated and the spectrum is deleted.
                //TODO modified the crosstalk condition

                         if (count == 6) {
                      occupiedTime.remove(i);
                //After deleting, there is no need to traverse here, just jump out of the innermost for loop and start looking for the next for loop.
                        break;
                      } else {
                        count++;
                   }
                      }
                }
               }
                //The result obtained in the previous step indicates that the available spectrum does not generate crosstalk.
                //This step sorts the results of the previous step into the form of available spectrum segments, ie List<List<Integer>>, and removes the spectrum segments that do not meet the length requirements.
                if (!occupiedTime.isEmpty()) {
               // return null;
              //  } else {
                	for (int i=0;i<occupiedTime.size(); i--) {

                	if (occupiedTime.size() >= requiredWaveNum) {
                		rtn1.add(occupiedTime.get(i));
                		}
                	//}

                return occupiedTime;
               // return rtn1;


               // }
                }
                }/**else {
                throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph！");
                }*/
              //  return occupiedTime;
               }
        				return occupiedTime;
                
        	} 	
          public TreeSet<Integer> checkAvaiSpectrumBlockInOrderSameIndex1tree( int requiredWaveNum) {
              TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();
              ArrayList<Integer> noCrosstalkSpectrumBlock=Lists.newArrayList(); ;

              //    ArrayList<Integer> avaiSpectrumBlock=Lists.newArrayList(); ;
          //    for (int j=0; j<coreList.size(); j++) {
             	         for (LinkCores sdmcores : coreList) {
             //	      		LinkCores sdmcores=coreList.get(j);
          //	for (LinkCores sdmcores: coreList) {

      	      	//	LinkCores sdmcores=coreList.get(j);


                 //     for (CoreSC coreSC:coreSCList) {
                  //    LinkCores sdmCore = edge.getCoreList().get(coreSC.getCoreIndex());


                              if (sdmcores != null){
                   //    first = findAvaiSpectrumBlocksInOrder1(sdmCore.getWavelength() , requiredWaveNum);
                             	  ArrayList<Integer> avaiSpectrumBlock=sdmcores.availableSlotsIndexList1();
                             	  
             //return first;
                           if (avaiSpectrumBlock != null) {
                         	   noCrosstalkSpectrumBlock =
                        	                     noCrossTalkFilterSameIndex1(sdmcores, avaiSpectrumBlock, requiredWaveNum);
                               if (noCrosstalkSpectrumBlock != null) {
                           //  return null;
                    //          		availableSlotsIndex.add(noCrosstalkSpectrumBlock.get(0));

                           // for (int i=0; i<noCrosstalkSpectrumBlock.size(); i++) {
                            //   		availableSlotsIndex.add(i);
                              // 		availableSlotsIndex.add(i);
                            for (int n : noCrosstalkSpectrumBlock) {
                             		availableSlotsIndex.add(n);
                               		

                      }              //  
                               }    	
                           }
                              }
             	 }
        return availableSlotsIndex;
        	}
          


  
    public Link2() {
    	
    	  //    	TopologyquantifiedDetails net = params.networks.get(i);
    	      //  TopologyParameters params = TopologySetup.getInstance().TopologyParams;


    	      //  slots = Lists.newArrayListWithCapacity(TopologyParameters.getInstance().slotNum);
    	        slots = Lists.newArrayListWithCapacity(10);

         for (int i=0;i<10;i++) {
    	            // slot index starts from 1.
    	            slots.add(new FrequencySlots(i+1));
    	        }
    	        coreList = new ArrayList<LinkCores>(7);
    	        for (int i = 0; i < 7; i++) {
    	            coreList.add(new LinkCores(i));
    	        }
    	        initAdjCores(); 	        
    	        
    	    }



public void setCoreList(List<LinkCores> coreList) {
this.coreList = coreList;
}

public void initAdjCores() {

coreList.get(0).addAdjCores(coreList.get(1));
coreList.get(0).addAdjCores(coreList.get(5));
coreList.get(0).addAdjCores(coreList.get(6));

coreList.get(1).addAdjCores(coreList.get(0));
coreList.get(1).addAdjCores(coreList.get(2));
coreList.get(1).addAdjCores(coreList.get(6));

coreList.get(2).addAdjCores(coreList.get(1));
coreList.get(2).addAdjCores(coreList.get(3));
coreList.get(2).addAdjCores(coreList.get(6));

coreList.get(3).addAdjCores(coreList.get(2));
coreList.get(3).addAdjCores(coreList.get(4));
coreList.get(3).addAdjCores(coreList.get(6));

coreList.get(4).addAdjCores(coreList.get(3));
coreList.get(4).addAdjCores(coreList.get(5));
coreList.get(4).addAdjCores(coreList.get(6));

coreList.get(5).addAdjCores(coreList.get(0));
coreList.get(5).addAdjCores(coreList.get(4));
coreList.get(5).addAdjCores(coreList.get(6));

coreList.get(6).addAdjCores(coreList.get(0));
coreList.get(6).addAdjCores(coreList.get(1));
coreList.get(6).addAdjCores(coreList.get(2));
coreList.get(6).addAdjCores(coreList.get(3));
coreList.get(6).addAdjCores(coreList.get(4));
coreList.get(6).addAdjCores(coreList.get(5));
////////////////////////////////////////////////
/*
coreList.get(0).addNonAdjCores(coreList.get(2));
coreList.get(0).addNonAdjCores(coreList.get(4));
coreList.get(0).addNonAdjCores(coreList.get(3));

coreList.get(1).addNonAdjCores(coreList.get(5));
coreList.get(1).addNonAdjCores(coreList.get(3));
coreList.get(1).addNonAdjCores(coreList.get(4));

coreList.get(2).addNonAdjCores(coreList.get(0));
coreList.get(2).addNonAdjCores(coreList.get(4));
coreList.get(2).addNonAdjCores(coreList.get(5));

coreList.get(3).addNonAdjCores(coreList.get(0));
coreList.get(3).addNonAdjCores(coreList.get(1));
coreList.get(3).addNonAdjCores(coreList.get(5));

coreList.get(4).addNonAdjCores(coreList.get(0));
coreList.get(4).addNonAdjCores(coreList.get(1));
coreList.get(4).addNonAdjCores(coreList.get(2));

coreList.get(5).addNonAdjCores(coreList.get(1));
coreList.get(5).addNonAdjCores(coreList.get(2));
coreList.get(5).addNonAdjCores(coreList.get(3));
coreList.get(6).addAdjCores(coreList.get(0));
coreList.get(6).addAdjCores(coreList.get(1));
coreList.get(6).addAdjCores(coreList.get(2));
coreList.get(6).addAdjCores(coreList.get(3));
coreList.get(6).addAdjCores(coreList.get(4));
coreList.get(6).addAdjCores(coreList.get(5));*/

}



@Override
public String toString() {
    //return Objects.toStringHelper(this)
    return MoreObjects.toStringHelper(this)

            .add("source", getSource())
            .add("destination", getTarget())
            .toString();
}

//public Link2 get(int edgeId1) {
	// TODO Auto-generated method stub
//	return null;
//}
}

package Network;


import java.util.List;


/**
 * Parsing parameters about EON networks.
 * Notification: There may be more than one network for simulation.
 * Created by yby on 2017/4/1.
 */
public class TopologyParameters {
    private static TopologyParameters ourInstance = new TopologyParameters();

    public static TopologyParameters getInstance() {
        return ourInstance;
    }

    public int slotNum;
    public List<TopologyquantifiedDetails> networks;

    // the unit of rou and miu is /min.
    // rou = rou_bias + rou_peak*(1+sin(-pi/2+pi/12*t)
    // time interval to change rou as equation shown before with unit minute.
    public int timeInterval;
    // bias arrival rate for cross vertexes of business area and residential area,
    // source for business, destination for residential
    public double rouBias;
    // peak arrival rate for business area
    public double rouBusinessPeak;
    // peak arrival rate for residential area
    public double rouResidentialPeak;
    public int cores;
    public int startingCore;
    public int EndingCore;



    // leave rate
    public double miu;


    // minimum required slot number per service
    public int minRequiredSlotNum;
    // maximum required slot number per service
    public int maxRequiredSlotNum;
    public List<TopologyquantifiedDetails> getNetwork() {
        return networks;
    }
    public void setNeighbors(List<TopologyquantifiedDetails> networks) {
        this.networks = networks;
    }

    public void addSingleEonNet(TopologyquantifiedDetails n){
    	networks.add(n);
    }


    public TopologyParameters() {

    }
}

package Network;


/**
 * Created by sambabel on 16-11-12.
 */
public enum NodeStatus {
    UP,
    DOWN
}

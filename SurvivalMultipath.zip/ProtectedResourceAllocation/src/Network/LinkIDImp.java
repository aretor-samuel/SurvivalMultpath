package Network;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by Boyuan on 16-11-13.
 * require ： Edge接口的Sdm网络Edge实现类
 * Sdm edge is identified by src and dst. if it's directed, src and dst should be in order.
 */
public class LinkIDImp implements LinkID{

    // The schema of id is "src-to-dst"
    String id;

    private static final Logger log  = LoggerFactory.getLogger(LinkIDImp.class);

    boolean isDirected = false;

   // public String getId() {
    public String getId() {

        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LinkIDImp(String id, boolean isDirected) {
        this.id = id;
        this.isDirected = isDirected;
    }

    /**
     * 
     * @return 
     */
    public LinkID reverse() {
        String[] str = id.split("-");
        if (str != null && str.length==3) {
            String reverseId = str[2] + "-" + str[1] + "-" + str[0];
            return new LinkIDImp(reverseId, isDirected);
        } else {
            log.error("reverse EdgeId failure - {}.", this);
            return null;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LinkIDImp sdmEdgeId = (LinkIDImp) o;

        if (isDirected != sdmEdgeId.isDirected) return false;

        boolean directedEqual = (id != null ? id.equals(sdmEdgeId.id) : sdmEdgeId.id == null);
        // if dual and not equal
        if (!isDirected && !directedEqual) {
            String[] arr = id.split("-");
            if (arr.length == 3) {
                String reverse = arr[2] + "-" + arr[1] +  "-" + arr[0];
                return reverse.equals(sdmEdgeId.id);
            } else {
                log.error("The format of EdgeId {} is not correct.", id);
            }
        }

        return directedEqual;
//        return id != null ? id.equals(sdmEdgeId.id) : sdmEdgeId.id == null;

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (isDirected ? 1 : 0);
        return result;
    }

    public boolean isDirected() {
        return isDirected;
    }

    @Override
    public String toString() {
        return id;
    }
}

package DataCollection;


//import org.jgrapht.Graph;
import Network.CoreSC;
import Network.FrequencySlots;
import Network.Link;
import Network.Link2;
import Network.LinkCores;
import Network.Node2;
import Network.TopologyParameters;

import org.jgrapht.graph.SimpleWeightedGraph;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * calculate utilization Rate
 * @author yby
 */
//public final class SpectrumUtilizationRate<Link2> {
	public final class SpectrumUtilizationRate {


    public static final double EMPTY_EDGE = -1;
    private static SpectrumUtilizationRate ourInstance = new SpectrumUtilizationRate();

    public static SpectrumUtilizationRate getInstance() {
        return ourInstance;
    }

    private SpectrumUtilizationRate() {
    }

    /**
     * calculate utilization Rate for one graph.
     * Notification: the size of slots contained by a E can be variable.
     * @param graph
     * @return utilization Rate or EMPTY_EDGE
     */
    //public double calculateUR(Graph graph) {
     public double calculateUR(SimpleWeightedGraph<Node2, Link2> graph) {
  	// LinkImplementation sdmEdge = (LinkImplementation) graph.getEdges();
        return calculateUR(graph.edgeSet());
    }

    /**
     * calculate utilization Rate for one edgeSet.
     * Notification: the size of slots contained by a E can be variable.
     * @param edgeSet
     * @return utilization Rate or EMPTY_EDGE
     */
     public double calculateUR(Set<Link2> edgeSet) {
         double totalSlotNum = 0.0d;
         double occupiedSlotNum = 0.0d;
         if (!edgeSet.isEmpty()) {
             for (Link2 edge : edgeSet) {
  	           List<LinkCores> sdmCorelist = edge.getCoreList();
  	            for (LinkCores sdmCore : sdmCorelist) {
  	  	        //   LinkCores sdmCore= sdmCorelist.get(0);
	
 	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();

             	// LinkImplementation sdmEdge = (LinkImplementation) edge;
                 totalSlotNum = totalSlotNum + wavelengths.size();
                 occupiedSlotNum = occupiedSlotNum + sdmCore.occupiedSlotsNum();
//                 occupiedSlotNum = occupiedSlotNum +  wavelengths.get(0).getOccupiedNum();

  	           }
             }
             return occupiedSlotNum / totalSlotNum;
         } else {
             return EMPTY_EDGE;
         }
     }


     /**
      * calculate utilization Rate for one edge.
      * @param edge
      * @return utilization Rate or EMPTY_EDGE.
      */
    // public double calculateUR(Link2 edge) {
         public double calculateUR(int OccupiedTotalNum) {

    //	 LinkImplementation sdmEdge = (LinkImplementation) edge;
     	double size = 0 ;
         double occupied = 0;
     
      /**   if (edge == null) {
             return EMPTY_EDGE;
         }
         List<LinkCores> sdmCorelist = edge.getCoreList();
          for (LinkCores sdmCore : sdmCorelist) {
          	
             List<FrequencySlots> wavelengths = sdmCore.getWavelength();

          size = wavelengths.size();
         // occupied = sdmCore.occupiedSlotsNum();
          occupied = wavelengths.get(0).getOccupiedNum();*/

         size = TopologyParameters.getInstance().slotNum*52;
	        
	     
         occupied=OccupiedTotalNum;
          
          
         //return occupied / size;
   //  }
 		return occupied / size;
     }
 }
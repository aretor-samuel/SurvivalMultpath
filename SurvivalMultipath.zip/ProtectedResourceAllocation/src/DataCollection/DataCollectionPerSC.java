package DataCollection;


import javafx.util.Pair;
//import output.sdmeon.ReProvisionType;
import DataCollection.SimResultPerErl;
import DataCollection.SimResultPerSC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import Network.CoreSC;
import Utility.ReProvisionType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author yby
 * 专门用于进行数据采集的类，需要采集的数据是业务量mu/rou，阻塞率，频谱利用率，频谱搬移次数，重构时间，频谱规整度等等.
 * <br/>
 * 该类使用说明：<br/>
 *   该类是用于进行一次指定频谱规整度阈值，不同业务量的反震结果的数据采集类。
 *   在进行仿真的时候，对于某个指定的重构算法（无重构，DSSC，SSDC），要进行批量的仿真，类似代码如下：<br/>
 *   <code>
 *       double dsThreshold = 20; // 先给定频谱规整度的阈值
 *       DataCollectionPerSC dc = new DataCollectionPerSC(,dsThreshold,,,); // 给定入参
 *       for (遍历业务量） {
 *           eventQueue; // 生成业务
 *           double erl = mu/rou; // erl表示本次仿真的业务量
 *           dc.startNewErl(mu, rou); // 开启一次指定频谱规整度阈值，指定业务量的仿真
 *
 *           // 接下来是仿真算法的具体内容
 *
 *       }
 *   </code>
 */
public class DataCollectionPerSC {

    private static final Logger log = LoggerFactory.getLogger(DataCollectionPerSC.class);

    // graph中拥有的所有频谱资源的个数
    private int allWavelengthNum;
    // 频谱规整度的阈值
    private double dsThreshold = -1;
    // 频谱利用率计算的间隔。这里的间隔的个数指的是事件的个数，不是业务的个数。
    private int interval = -1;
    // 重构类型
   private ReProvisionType type;
    // 所有的事件个数，一个业务对应两个事件
    private int eventTotalNum;

    private List<DataCollectionPerErl> dcPerErl = new ArrayList<DataCollectionPerErl>();

    // 当前测试的指针
    private DataCollectionPerErl pointerNow;

    /**
     * 开始新一轮的指定频谱规整度阈值，指定业务量的仿真
     * @param mu mu
     * @param rou rou
     */
    public void startNewErl(double mu, double rou) {
        pointerNow = new DataCollectionPerErl(mu, rou);
        dcPerErl.add(pointerNow);
    }

    /**
     * 增加阻塞的事件个数
     */
    public void addBlockedEventNum() {
        pointerNow.addBlockedEventNum();
    }

    /**
     * 增加频谱利用率的值
     * @param eventIndex 当前已经处理完的事件的id,注意，这里的事件id不是eventId，仅仅是事件的个数。
     * @param eventInfo 当前的占用资源的业务信息
     */
    public void addSpectrumUtil(int eventIndex, Map<Integer, Pair<List<CoreSC>, List<Integer>>> eventInfo) {
        pointerNow.addSpectrumUtil(eventIndex, eventInfo, allWavelengthNum);

    }

    /**
     * 增加频谱搬移成功次数
     */
    public void addSpectrumSuccessShiftNum() {
        pointerNow.addSpectrumSuccesshiftNum();
    }

    /**
     * 增加频谱搬移次数
     */
    public void addSpectrumShiftNum() {
        pointerNow.addSpectrumShiftNum();
    }

    /**
     * 增加重构时间的值。
     * <br/>一定要是重构成功，这个时间才会计入。
     * @param eventIndex 当前已经处理完的事件的id，注意，这里的事件id不是eventId，仅仅是事件的个数。
     * @param start 重构的开始时间
     * @param end 重构的结束时间
     */
    public void addReconstructTime(int eventIndex, long start, long end) {
        pointerNow.addReconstructTime(eventIndex, start, end);
    }


   public DataCollectionPerSC(int allWavelengthNum, double dsThreshold, int interval, ReProvisionType type, int eventTotalNum) {
      //  public DataCollectionPerSC(int allWavelengthNum, double dsThreshold, int interval, int eventTotalNum) {
        this.allWavelengthNum = allWavelengthNum;
        this.dsThreshold = dsThreshold;
        this.interval = interval;
     //   this.type = type;
        this.eventTotalNum = eventTotalNum;
    }

    /**
     * 根据本对象的内容，构造SimResultPerSC的实例，用于最终的数据输出
     * @return SimResultPerSC的实例
     */
    public SimResultPerSC build() {
        List<SimResultPerErl> list = new ArrayList<SimResultPerErl>();
        for (DataCollectionPerErl erl : dcPerErl) {
            list.add(erl.build(eventTotalNum));
        }
        return new SimResultPerSC(dsThreshold, list, interval);
    }

    public int getInterval() {
        return interval;
    }
}

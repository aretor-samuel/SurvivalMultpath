package DataCollection;


import java.util.ArrayList;
import java.util.List;

//import net.impl.sdmeon.link.SdmWavelength;

/**
 * @author sambabel
*
 */
public class SimResultPerSC {
    private static double dsThreshold = -1;
    private List<SimResultPerErl> resultPerErls;
   // private List<SimResultPerErl> resultPerErls= new ArrayList<SimResultPerErl>(10);


    // 在计算频谱利用率的时候，每隔多少个业务取一次值。
    private static int interval = -1;

    public static double getDsThreshold() {
        return dsThreshold;
    }

    public void setDsThreshold(double dsThreshold) {
        this.dsThreshold = dsThreshold;
    }

    public List<SimResultPerErl> getResultPerErls() {
        return resultPerErls;
    }

    public void setResultPerErls(List<SimResultPerErl> resultPerErls) {
        this.resultPerErls = resultPerErls;
    }

    public static int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    public SimResultPerSC() {
    }

    public SimResultPerSC(double dsThreshold, List<SimResultPerErl> resultPerErls, int interval) {
        this.dsThreshold = dsThreshold;
        this.resultPerErls = resultPerErls;
        this.interval = interval;
    }
    public static void main(String[] args)  {
        System.out.println(getDsThreshold());
        System.out.println(getInterval());

    }
}

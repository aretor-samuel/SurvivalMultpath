package DataCollection;




/**
 * @author yby
 * 指定频谱规整度阈值的情况下，每个业务发生器的业务量erlang的仿真结果
 */
public class SimResultPerErl {
    // 业务发生器的mu
    private double mu = -1;
    // 业务发生器的rou
    private double rou = -1;
    // 阻塞率
    private double blockRatio = -1;
    // 每隔interval个业务取一次值，然后取平均
    private double spetrumUtilization = -1;
    // 频谱搬移成功的总次数
    private double spectrumSuccessShiftNums = -1;
    // 从项目一开始到最后的频谱搬移次数
    private double spectrumShiftNums = -1;
    // 单位是ms
    private double reconstructTime = -1;

    public double getMu() {
        return mu;
    }

    public void setMu(double mu) {
        this.mu = mu;
    }

    public double getRou() {
        return rou;
    }

    public void setRou(double rou) {
        this.rou = rou;
    }

    public double getSpetrumUtilization() {
        return spetrumUtilization;
    }

    public void setSpetrumUtilization(double spetrumUtilization) {
        this.spetrumUtilization = spetrumUtilization;
    }

    public double getSpectrumSuccessShiftNums() {
        return spectrumSuccessShiftNums;
    }

    public void setSpectrumSuccessShiftNums(double spectrumSuccessShiftNums) {
        this.spectrumSuccessShiftNums = spectrumSuccessShiftNums;
    }

    public double getSpectrumShiftNums() {
        return spectrumShiftNums;
    }

    public void setSpectrumShiftNums(double spectrumShiftNums) {
        this.spectrumShiftNums = spectrumShiftNums;
    }

    public double getReconstructTime() {
        return reconstructTime;
    }

    public void setReconstructTime(double reconstructTime) {
        this.reconstructTime = reconstructTime;
    }

    public double getBlockRatio() {
        return blockRatio;
    }

    public void setBlockRatio(double blockRatio) {
        this.blockRatio = blockRatio;
    }

    public SimResultPerErl() {
    }

    public SimResultPerErl(double mu, double rou, double blockRatio, double spetrumUtilization, double spectrumShiftNums,
                           double spectrumSuccessShiftNums,double reconstructTime) {
        this.mu = mu;
        this.rou = rou;
        this.blockRatio = blockRatio;
        this.spetrumUtilization = spetrumUtilization;
        this.spectrumShiftNums = spectrumShiftNums;
        this.spectrumSuccessShiftNums = spectrumSuccessShiftNums;
        this.reconstructTime = reconstructTime;
    }
}

package TrafficGeneration;


import java.io.Serializable;
import java.util.Calendar;

import org.jgrapht.alg.util.Pair;

//import com.google.common.base.MoreObjects;

/**
 * Service.
 * Created by yby on 2019/04/12.
 */
public class Service implements Serializable {
    //
    private int index;

    private Calendar startTime;

    private Calendar endTime;
     private Pair<Integer, Integer>Coreset;
    private int requiredSlotNum;

    private int source;
    private int core1;
    private double rou;


    private int destination;

	private int core2;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Service service = (Service) o;

        return index == service.index;

    }

    @Override
    public int hashCode() {
        return index;
    }


  //  public int getIndex() {
        public int getEventId() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
    public double getRou() {
        return rou;
    }
    public void setRou(double rou) {
        this.rou = rou;
    }

    public Calendar getStartTime() {
        return startTime;
    }

    public void setStartTime(Calendar startTime) {
        this.startTime = startTime;
    }

    public Calendar getEndTime() {
        return endTime;
    }

    public void setEndTime(Calendar endTime) {
        this.endTime = endTime;
    }
    public int getCore1() {
        return core1;
    }
    public void setCore1(int core1) {
        this.core1 = core1;
    }
    public int getCore2() {
        return core2;
    }
    public void setCore2(int core2) {
        this.core2 = core2;
    }
   // getRequiredWaveNum

   // public int getRequiredSlotNum() {
    public int getRequiredWaveNum() {

        return requiredSlotNum;
    }

    public void setRequiredWaveNum(int retuiredSlotNum) {
        this.requiredSlotNum = retuiredSlotNum;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public int getDestination() {
        return destination;
    }

    public void setDestination(int destination) {
        this.destination = destination;
    }

  //  public Service(int index, Calendar startTime, Calendar endTime, Pair<Integer, Integer>Coreset , int retuiredSlotNum, int source, int destination) {
 //  public Service(int index,  double rou, Calendar startTime, Calendar endTime,  int retuiredSlotNum, int source, int destination) {
	   public Service(int index,  Calendar startTime, Calendar endTime,  int retuiredSlotNum, int source, int destination) {


        this.index = index;
        this.rou = rou;

        this.Coreset = Coreset;
        this.startTime = startTime;
        this.endTime = endTime;
        this.requiredSlotNum = retuiredSlotNum;
        this.source = source;
        this.destination = destination;
    }
  

}

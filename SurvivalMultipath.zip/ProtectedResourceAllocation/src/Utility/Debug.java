package Utility;


/**
 *  Debuging tool
 * @author sambabel
 */
public class Debug {

    public static final boolean ENABLE_DEBUG = true;

    private Debug() {
    }
}

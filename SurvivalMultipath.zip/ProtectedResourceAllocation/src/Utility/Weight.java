package Utility;




import java.util.Map;

/**
 * @author sam
 */
public interface Weight {
    /**

     * @return
     */
    Map<WeightType, Double> getWeights();


    /**
     * 
     * @param weightType
     * @return 
     */
    double getWeight(WeightType weightType);

    /**
     * 
     * @param type 
     * @param value 
     */
    void addWeight(WeightType type, double value);
}

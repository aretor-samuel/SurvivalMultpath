package Utility;

/**
 * Created by sambabel on 2019-05-25.
 */
public enum LinkType {
    COPPER,
    FIBER,
    WIRELESS
}

package Graph;

public class MatrixException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7339203246151787865L;

	public MatrixException(String message) {
		super(message);
	}
}
